import React, { useState, useEffect } from 'react';
import { HOLY_PRODUCTS } from '../data/mockData';
import { ShoppingBag, Coins, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';

const Shop: React.FC = () => {
  const [shukiCoins, setShukiCoins] = useState(1200);
  const [boughtItems, setBoughtItems] = useState<number[]>([]);

  // Periodically generate coins because of divine benevolence
  useEffect(() => {
    const timer = setInterval(() => {
      setShukiCoins((prev) => prev + 10);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  const handleBuy = (id: number, price: number) => {
    if (shukiCoins < price) return;

    setShukiCoins((prev) => prev - price);
    setBoughtItems([...boughtItems, id]);

    confetti({
      particleCount: 80,
      spread: 50,
      origin: { y: 0.8 },
      colors: ['#f59e0b', '#10b981']
    });
  };

  return (
    <div className="min-h-screen bg-slate-900 text-gray-100 py-12 px-4 md:px-8">
      {/* Header and Currency Display */}
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between border-b border-yellow-500/20 pb-8 mb-12 gap-6">
        <div>
          <h2 className="font-['Amatic_SC'] text-5xl md:text-6xl text-yellow-400 font-bold tracking-wide flex items-center gap-2">
            <ShoppingBag className="w-10 h-10 text-yellow-500 animate-pulse" /> אוצרות המקדש
          </h2>
          <p className="text-gray-400 text-sm mt-1">רכוש תשמישי קדושה והעלה את הדרגה הרוחנית שלך בקהילה.</p>
        </div>

        {/* Shuki Coin wallet */}
        <div className="bg-slate-950 border-2 border-yellow-500/50 rounded-2xl p-4 flex items-center gap-4 shadow-[0_0_20px_rgba(234,179,8,0.2)]">
          <div className="bg-yellow-500/20 p-3 rounded-full">
            <Coins className="w-8 h-8 text-yellow-400 animate-spin-slow" />
          </div>
          <div>
            <span className="text-xs text-yellow-400/80 block font-bold uppercase tracking-wider">יתרת מטבעות קודש</span>
            <span className="text-3xl font-black tabular-nums text-yellow-200">{shukiCoins.toLocaleString()} <span className="text-lg">💰</span></span>
            <span className="text-[10px] block text-green-400 mt-1 animate-pulse">השפע ממשיך לזרום (10+ בכל כמה שניות)</span>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {HOLY_PRODUCTS.map((product) => {
          const isBought = boughtItems.includes(product.id);
          const canAfford = shukiCoins >= product.price;

          return (
            <div
              key={product.id}
              className={`bg-slate-950/60 border rounded-2xl p-6 flex flex-col justify-between transition-all duration-300 relative group hover:-translate-y-2 hover:shadow-2xl ${
                isBought
                  ? 'border-green-500/40 shadow-green-500/10'
                  : 'border-slate-800 hover:border-yellow-500/30 shadow-black'
              }`}
            >
              <div>
                <div className="text-5xl mb-4 bg-slate-900 w-20 h-20 rounded-2xl flex items-center justify-center border border-slate-800 group-hover:scale-110 transition-transform">
                  {product.image}
                </div>
                <h4 className="text-xl font-bold text-yellow-100 mb-2">{product.name}</h4>
                <p className="text-gray-400 text-xs leading-relaxed mb-4">{product.description}</p>
                <span className="inline-block px-3 py-1 bg-amber-950/60 border border-amber-600/40 text-amber-300 rounded-full text-xs font-semibold mb-6">
                  {product.power}
                </span>
              </div>

              <div>
                <div className="flex items-baseline justify-between mb-4 border-t border-slate-900 pt-4">
                  <span className="text-xs text-gray-500 font-bold">מחיר שמימי:</span>
                  <span className="text-xl font-black text-yellow-400">{product.price} 💰</span>
                </div>

                {isBought ? (
                  <div className="w-full py-3 bg-green-600/20 border border-green-500 text-green-300 font-bold rounded-xl flex items-center justify-center gap-1 text-sm">
                    <CheckCircle2 className="w-4 h-4" /> בבעלותך (האנרגיה פעילה)
                  </div>
                ) : (
                  <button
                    onClick={() => handleBuy(product.id, product.price)}
                    disabled={!canAfford}
                    className={`w-full py-3 font-bold rounded-xl cursor-pointer transition text-center text-sm ${
                      canAfford
                        ? 'bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-400 hover:to-amber-500 text-slate-950 shadow-md'
                        : 'bg-slate-800 text-gray-600 cursor-not-allowed border border-slate-700'
                    }`}
                  >
                    {canAfford ? 'רכוש עם מטבעות' : 'אין לך מספיק מטבעות'}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Shop;
