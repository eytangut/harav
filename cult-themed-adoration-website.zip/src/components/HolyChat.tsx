import React, { useState, useEffect, useRef } from 'react';
import { MessageCircleCode, Send } from 'lucide-react';

interface ChatMessage {
  id: number;
  user: string;
  text: string;
  time: string;
  isUser?: boolean;
}

const HolyChat: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: 1, user: "אביחי המאמין", text: "שוקי המלך! כל היום חושב עליו", time: "12:30" },
    { id: 2, user: "רונית מחדרה", text: "למישהו יש מושג מתי הוא יוצא לקניות? רוצה לגעת ברכבו", time: "12:31" },
    { id: 3, user: "גורו-מאסטר", text: "השתחוו לשוקי פן יחשיך עליכם קודכם", time: "12:33" },
    { id: 4, user: "אלון77", text: "שוקי פרידמן הוא פשוט אגדה חיה! חולה עליו", time: "12:34" }
  ]);

  const [inputText, setInputText] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const botResponses = [
    "יישר כוח צדיק!",
    "שוקי מעריך את ההקרבה שלך.",
    "שוקיזם זו לא רק דרך חיים, זו הדרך היחידה.",
    "מי שמדבר סרה בשוקי - דינו חיתוך סיבים אופטיים.",
    "הללויה!",
    "שוקי פרידמן אורנו ואמונתנו.",
    "קוד נקי, מוח נקי, שוקי בשחקים."
  ];

  const botNames = ["שמעון מנהל", "אורית הצדיקה", "כת_שוקי_לנצח", "חסיד_רדיקלי", "נציג_הרב"];

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Simulate incoming community messages
  useEffect(() => {
    const interval = setInterval(() => {
      const randomUser = botNames[Math.floor(Math.random() * botNames.length)];
      const randomMsg = botResponses[Math.floor(Math.random() * botResponses.length)];
      const now = new Date();
      const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

      setMessages((prev) => [
        ...prev,
        { id: Date.now(), user: randomUser, text: randomMsg, time: timeStr }
      ]);
    }, 6000);

    return () => clearInterval(interval);
  }, []);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    setMessages((prev) => [
      ...prev,
      { id: Date.now(), user: "אני (חסיד)", text: inputText, time: timeStr, isUser: true }
    ]);

    setInputText('');
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center py-12 px-4">
      <div className="w-full max-w-2xl h-[600px] bg-slate-950/80 border border-yellow-500/30 rounded-3xl flex flex-col shadow-2xl relative">
        
        {/* Header */}
        <div className="p-4 bg-slate-900 border-b border-yellow-500/20 rounded-t-3xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="relative">
              <MessageCircleCode className="w-6 h-6 text-yellow-400 animate-pulse" />
              <div className="absolute top-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border border-slate-950 animate-ping"></div>
            </div>
            <h3 className="text-lg font-bold text-yellow-100">צ'אט המעגל הפנימי</h3>
          </div>
          <span className="text-xs text-green-400 font-mono flex items-center gap-1">
             ● מחובר ישירות לשכינה
          </span>
        </div>

        {/* Messages Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col max-w-[75%] ${msg.isUser ? 'mr-auto items-start' : 'ml-auto items-end text-right'}`}
            >
              <div className={`flex items-baseline gap-2 mb-1 ${msg.isUser ? 'flex-row' : 'flex-row-reverse'}`}>
                <span className={`text-xs font-bold ${msg.isUser ? 'text-yellow-400' : 'text-amber-500'}`}>
                  {msg.user}
                </span>
                <span className="text-[10px] text-gray-500">{msg.time}</span>
              </div>
              <div
                className={`p-3 rounded-2xl text-sm leading-relaxed border ${
                  msg.isUser
                    ? 'bg-yellow-500 text-slate-950 font-bold rounded-tl-none border-yellow-400 shadow-[0_2px_10px_rgba(234,179,8,0.2)]'
                    : 'bg-slate-800 text-slate-100 rounded-tr-none border-slate-700/50'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>

        {/* Input Form */}
        <form onSubmit={handleSendMessage} className="p-4 bg-slate-900 border-t border-yellow-500/20 rounded-b-3xl flex gap-3">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="כתוב דברי שבח לרב..."
            className="flex-1 bg-slate-800 border border-slate-700 rounded-xl p-3 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-yellow-500"
          />
          <button
            type="submit"
            className="p-3 bg-yellow-500 hover:bg-yellow-400 active:bg-yellow-600 text-slate-950 font-bold rounded-xl cursor-pointer transition shadow-md flex items-center justify-center"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>

      </div>
    </div>
  );
};

export default HolyChat;
