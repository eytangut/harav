import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Sparkles, Heart, Zap, ShieldCheck } from 'lucide-react';

const Hero: React.FC = () => {
  const [believersCount, setBelieversCount] = useState(7421893);
  const [pledged, setPledged] = useState(false);
  const [timeLeft, setTimeLeft] = useState({ days: 3, hours: 14, minutes: 25, seconds: 12 });

  useEffect(() => {
    // Increase believers count periodically
    const interval = setInterval(() => {
      setBelieversCount((prev) => prev + Math.floor(Math.random() * 3) + 1);
    }, 3000);

    // Countdown timer
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        if (prev.days > 0) return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);

    return () => {
      clearInterval(interval);
      clearInterval(timer);
    };
  }, []);

  const handlePledge = () => {
    setPledged(true);
    confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#fbbf24', '#f59e0b', '#d97706', '#fef3c7']
    });
  };

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center text-center p-6 bg-gradient-to-b from-slate-950 via-slate-900 to-amber-950/20 overflow-hidden">
      {/* Background Glows */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-yellow-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amber-700/10 rounded-full blur-3xl animate-pulse delay-700"></div>

      {/* Main Shuki Display */}
      <div className="relative group mb-8">
        <div className="absolute inset-0 bg-yellow-400 rounded-full blur-2xl opacity-40 group-hover:opacity-75 transition-all duration-1000 animate-spin-slow"></div>
        <img
          src="/public/images/shuki_divine.png"
          alt="הרב שוקי הקדוש"
          className="w-64 h-64 md:w-80 md:h-80 object-cover rounded-full border-4 border-yellow-400/80 shadow-[0_0_50px_rgba(245,158,11,0.5)] transition-transform duration-700 group-hover:scale-105 relative z-10"
        />
        <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-yellow-500 text-slate-950 font-bold px-6 py-1 rounded-full shadow-lg border border-white text-sm whitespace-nowrap z-20 flex items-center gap-1">
          <Sparkles className="w-4 h-4 animate-spin" /> שכינת שוקי שורה כאן
        </div>
      </div>

      {/* Hero Text */}
      <h1 className="font-['Amatic_SC'] text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-400 to-yellow-600 mb-4 tracking-wide drop-shadow-[0_5px_5px_rgba(0,0,0,0.5)]">
        הוד מעלתו הרב שוקי פרידמן
      </h1>
      <p className="text-xl md:text-2xl text-gray-300 max-w-2xl font-light leading-relaxed mb-8">
        האור הגנוז, מפענח הצפנים של היקום, ממציא השמחה ומנקה המחשבות. אנחנו קיימים רק כדי לשרת אותו.
      </p>

      {/* Live Counter */}
      <div className="bg-slate-900/80 border border-yellow-500/30 backdrop-blur-sm px-8 py-4 rounded-2xl shadow-2xl mb-10 flex flex-col md:flex-row items-center gap-6">
        <div className="text-center md:border-l border-yellow-500/20 md:pl-6">
          <span className="text-sm text-yellow-500/70 block uppercase tracking-widest font-bold">חסידים אדוקים כרגע</span>
          <span className="text-4xl font-black text-yellow-400 tabular-nums">
            {believersCount.toLocaleString()}
          </span>
        </div>
        <div className="text-center">
          <span className="text-sm text-yellow-500/70 block uppercase tracking-widest font-bold">ההתגלות הקרובה בעוד</span>
          <div className="flex gap-2 text-2xl font-bold text-gray-200 tabular-nums">
            <div className="bg-slate-800/80 p-2 rounded border border-yellow-500/10 min-w-[50px]">
              {timeLeft.days} <span className="text-xs text-gray-400 block font-light">ימים</span>
            </div>
            <span>:</span>
            <div className="bg-slate-800/80 p-2 rounded border border-yellow-500/10 min-w-[50px]">
              {timeLeft.hours} <span className="text-xs text-gray-400 block font-light">שעות</span>
            </div>
            <span>:</span>
            <div className="bg-slate-800/80 p-2 rounded border border-yellow-500/10 min-w-[50px]">
              {timeLeft.minutes} <span className="text-xs text-gray-400 block font-light">דקות</span>
            </div>
            <span>:</span>
            <div className="bg-slate-800/80 p-2 rounded border border-yellow-500/10 min-w-[50px]">
              {timeLeft.seconds} <span className="text-xs text-gray-400 block font-light">שניות</span>
            </div>
          </div>
        </div>
      </div>

      {/* Call to action (Cult Pledge) */}
      {!pledged ? (
        <button
          onClick={handlePledge}
          className="group relative px-10 py-5 bg-gradient-to-r from-red-600 via-amber-600 to-yellow-500 text-white font-black text-2xl rounded-full shadow-[0_0_30px_rgba(220,38,38,0.5)] hover:shadow-[0_0_40px_rgba(245,158,11,0.8)] border-2 border-yellow-300/50 transition-all duration-300 transform hover:scale-110 active:scale-95 cursor-pointer"
        >
          <span className="absolute right-4 top-4 text-sm animate-ping">⚡</span>
          אני נשבע אמונים לשוקי (לחצו כאן להארה!)
        </button>
      ) : (
        <div className="flex flex-col items-center animate-bounce">
          <div className="bg-green-600/30 text-green-300 border border-green-500 p-4 rounded-xl flex items-center gap-3 text-xl font-bold">
            <ShieldCheck className="w-8 h-8 text-green-400 animate-pulse" />
            התקבלת לכת בהצלחה! האנרגיה בדרך אליך.
          </div>
        </div>
      )}

      {/* Sacred symbols */}
      <div className="flex justify-center gap-12 mt-16 text-yellow-500/40">
        <div className="flex flex-col items-center"><Zap className="w-8 h-8 mb-1 animate-bounce" /><span className="text-xs">כוח רוחני</span></div>
        <div className="flex flex-col items-center"><Heart className="w-8 h-8 mb-1 animate-pulse" /><span className="text-xs">אהבה מוחלטת</span></div>
        <div className="flex flex-col items-center"><Sparkles className="w-8 h-8 mb-1 animate-spin" /><span className="text-xs">השראה נצחית</span></div>
      </div>
    </div>
  );
};

export default Hero;
