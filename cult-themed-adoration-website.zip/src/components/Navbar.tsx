import React from 'react';
import { Sparkles, BookOpen, Gift, Award, MessageCircle, ShieldAlert } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'home', label: 'היכל הקודש', icon: <Sparkles className="w-5 h-5 text-yellow-400 animate-pulse" /> },
    { id: 'wisdom', label: 'תורת השוקיזם', icon: <BookOpen className="w-5 h-5 text-yellow-400" /> },
    { id: 'miracles', label: 'נסים ונפלאות', icon: <Award className="w-5 h-5 text-yellow-400" /> },
    { id: 'shop', label: 'אוצרות המקדש', icon: <Gift className="w-5 h-5 text-yellow-400" /> },
    { id: 'quiz', label: 'מבחן הראויות', icon: <ShieldAlert className="w-5 h-5 text-yellow-400" /> },
    { id: 'chat', label: 'קהל החסידים', icon: <MessageCircle className="w-5 h-5 text-yellow-400" /> },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-slate-950/90 backdrop-blur-md border-b border-yellow-600/30 shadow-[0_4px_30px_rgba(234,179,8,0.1)]">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2 space-x-reverse cursor-pointer" onClick={() => setActiveTab('home')}>
            <div className="relative">
              <div className="absolute inset-0 bg-yellow-500 blur-md rounded-full opacity-60 animate-pulse"></div>
              <span className="text-3xl relative">👑</span>
            </div>
            <span className="font-['Amatic_SC'] text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-amber-200 to-yellow-500 tracking-wider">
              ממלכת שוקיזם
            </span>
          </div>

          {/* Nav Items */}
          <div className="hidden md:flex space-x-1 space-x-reverse">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-yellow-600 to-amber-700 text-white shadow-lg shadow-yellow-600/20 scale-105 border border-yellow-400/50'
                    : 'text-gray-400 hover:text-yellow-200 hover:bg-white/5'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Mobile indicator */}
          <div className="md:hidden flex space-x-2 space-x-reverse overflow-x-auto py-2 max-w-[200px]">
             {tabs.find(t => t.id === activeTab)?.label}
          </div>
        </div>
      </div>
      
      {/* Mobile nav buttons */}
      <div className="md:hidden flex justify-around bg-slate-900/95 border-t border-yellow-600/20 py-2">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex flex-col items-center gap-1 p-1 text-xs transition-all ${
              activeTab === tab.id ? 'text-yellow-400 scale-110 font-bold' : 'text-gray-500'
            }`}
          >
            {tab.icon}
            <span className="text-[10px]">{tab.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
};

export default Navbar;
