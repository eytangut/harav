import React, { useState } from 'react';
import { CULT_QUIZ } from '../data/mockData';
import { HelpCircle, RefreshCcw, Award } from 'lucide-react';
import confetti from 'canvas-confetti';

const Quiz: React.FC = () => {
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  const handleAnswerSelection = (selectedIdx: number) => {
    if (selectedIdx === CULT_QUIZ[currentQuestionIdx].correctIdx) {
      setScore(score + 1);
    }

    if (currentQuestionIdx + 1 < CULT_QUIZ.length) {
      setCurrentQuestionIdx(currentQuestionIdx + 1);
    } else {
      setIsFinished(true);
      if (score >= 2) {
        confetti({ particleCount: 150, spread: 80 });
      }
    }
  };

  const restartQuiz = () => {
    setCurrentQuestionIdx(0);
    setScore(0);
    setIsFinished(false);
  };

  const getEvaluation = () => {
    const total = CULT_QUIZ.length;
    const ratio = score / total;

    if (ratio === 1) return {
      title: "חסיד מואר מן המניין!",
      description: "אתה נאמן לחלוטין. מפתחות הממלכה מחכות לך. אנרגיית השוקי זורמת בך.",
      status: "קדוש",
      bg: "border-green-500 bg-green-500/10 text-green-300"
    };
    if (ratio >= 0.6) return {
      title: "מאמין מתלמד",
      description: "יש לך פוטנציאל, אך דעתך נודדת מדי פעם. מומלץ להעביר מעשר נוסף להגברת הריכוז.",
      status: "חצי קדוש",
      bg: "border-yellow-500 bg-yellow-500/10 text-yellow-300"
    };
    return {
      title: "כופר מסוכן!!!",
      description: "עליך לעשות תשובה מרובה. אתה מחזיק בדעות עצמאיות מדי עבור חברות בכת. היזהר!",
      status: "סכנת שמיים",
      bg: "border-red-600 bg-red-600/10 text-red-300"
    };
  };

  const evalResult = isFinished ? getEvaluation() : null;

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center py-12 px-4">
      <div className="w-full max-w-xl bg-slate-950/80 border border-yellow-500/20 shadow-[0_15px_40px_rgba(0,0,0,0.5)] rounded-3xl p-8 relative overflow-hidden">
        
        {!isFinished ? (
          <div>
            <div className="flex items-center gap-3 mb-6 border-b border-slate-800 pb-4">
              <HelpCircle className="w-8 h-8 text-yellow-500 animate-pulse" />
              <h3 className="text-2xl font-bold text-gray-200">
                מבחן ההתאמה לקהילה
              </h3>
            </div>

            {/* Progress */}
            <div className="text-xs text-yellow-500 mb-2 font-bold tracking-widest">
              שאלה {currentQuestionIdx + 1} מתוך {CULT_QUIZ.length}
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full mb-8">
              <div 
                className="bg-yellow-500 h-2 rounded-full transition-all duration-500" 
                style={{ width: `${((currentQuestionIdx + 1) / CULT_QUIZ.length) * 100}%` }}
              ></div>
            </div>

            {/* Question */}
            <h4 className="text-xl font-medium text-yellow-100 mb-6">
              {CULT_QUIZ[currentQuestionIdx].question}
            </h4>

            {/* Options */}
            <div className="space-y-4">
              {CULT_QUIZ[currentQuestionIdx].options.map((option, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAnswerSelection(idx)}
                  className="w-full text-right px-5 py-4 bg-slate-900 border border-slate-800 hover:border-yellow-500/40 rounded-xl text-gray-300 font-medium transition duration-200 transform hover:-translate-y-1 hover:bg-slate-800/50 cursor-pointer"
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center animate-fade-in flex flex-col items-center">
            <Award className="w-20 h-20 text-yellow-400 mb-4 animate-bounce" />
            <h3 className="text-3xl font-black text-gray-100 mb-2">
              המבחן הסתיים בהצלחה!
            </h3>
            <p className="text-gray-400 text-sm mb-6">התוצאות נרשמו בספר הדברי הימים של שוקי.</p>

            <div className={`w-full border-2 p-6 rounded-2xl mb-8 flex flex-col items-center justify-center ${evalResult?.bg}`}>
              <span className="text-sm font-bold tracking-wider mb-1 uppercase">סטטוס: {evalResult?.status}</span>
              <h4 className="text-2xl font-black mb-3">{evalResult?.title}</h4>
              <p className="text-md font-light leading-relaxed max-w-sm">{evalResult?.description}</p>
            </div>

            <button
              onClick={restartQuiz}
              className="flex items-center gap-2 px-6 py-3 bg-slate-800 hover:bg-yellow-500 hover:text-slate-950 font-bold rounded-full transition duration-300 cursor-pointer border border-yellow-500/30 shadow-md"
            >
              <RefreshCcw className="w-4 h-4" /> נסה שוב
            </button>
          </div>
        )}

      </div>
    </div>
  );
};

export default Quiz;
