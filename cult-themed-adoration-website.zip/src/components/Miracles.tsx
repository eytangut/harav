import React, { useState } from 'react';
import { HOLY_MIRACLES } from '../data/mockData';
import { ShieldCheck, Sparkles, Send, Star, Wand2 } from 'lucide-react';
import confetti from 'canvas-confetti';

const Miracles: React.FC = () => {
  const [miracles, setMiracles] = useState(HOLY_MIRACLES);
  const [newName, setNewName] = useState('');
  const [newText, setNewText] = useState('');

  // Blessing Generator States
  const [userName, setUserName] = useState('');
  const [blessingType, setBlessingType] = useState('עושר');
  const [customBlessing, setCustomBlessing] = useState('');

  const handleAddMiracle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newText.trim()) return;

    setMiracles([{ name: newName, text: newText, rating: 5 }, ...miracles]);
    setNewName('');
    setNewText('');

    confetti({
      particleCount: 50,
      spread: 60,
      colors: ['#34d399', '#10b981']
    });
  };

  const generateBlessing = () => {
    if (!userName.trim()) return;
    
    const blessings: { [key: string]: string[] } = {
      עושר: [
        "שחשבון הבנק שלך יתנפח כמו האגו של השוקיסטים הצעירים. מזומן ייפול עליך מהתקרה!",
        "תזכה לקבל החזרים ממס הכנסה על דברים שבכלל לא שילמת עליהם.",
        "הארנק שלך לא ייסגר מרוב שטרות של מאתיים שקלים."
      ],
      בריאות: [
        "עמוד השדרה שלך יתיישר לחלוטין כמו שורת קוד ב-Prettier.",
        "התאים שלך יתחדשו במהירות האור. תישאר צעיר לנצח.",
        "שום חיידק לא יעז להתקרב למערכת החיסונית המבורכת שלך."
      ],
      'קוד תקין': [
        "שגיאות הקומפילציה שלך ייעלמו עוד לפני שתלחץ על שמירה.",
        "הקוד שלך ירוץ במהירות ה-O(1) תמיד ובכל מצב.",
        "ה-AI יכתוב עבורך את כל הפרויקט ואתה רק תשתה אספרסו."
      ],
      'חסינות מדוחות': [
        "כל פקח שינסה לכתוב לך דו\"ח ישכח מדוע הגיע לשם ויחייך אליך.",
        "תמצא חניה חינם תמיד בתל אביב, במקומות הכי עמוסים.",
        "מצלמות המהירות ייכבו בדיוק כשתעבור על פניהן."
      ]
    };

    const typeList = blessings[blessingType] || blessings['עושר'];
    const randomBlessing = typeList[Math.floor(Math.random() * typeList.length)];

    setCustomBlessing(`בסייעתא דשוקיא, המאמין/ה ${userName}, הריני גוזר עליך מלמעלה: ${randomBlessing}`);

    confetti({
      particleCount: 100,
      spread: 100,
      origin: { y: 0.5 },
      colors: ['#eab308', '#f59e0b', '#dc2626']
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-gray-100 py-12 px-4 md:px-8">
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12">
        
        {/* Blessing Generator */}
        <div className="bg-slate-900/50 border border-yellow-500/20 rounded-3xl p-6 shadow-2xl backdrop-blur-sm relative">
          <div className="absolute inset-0 bg-yellow-500/5 filter blur-3xl -z-10"></div>
          <h3 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-amber-500 mb-6 flex items-center gap-2">
            <Wand2 className="w-8 h-8 text-yellow-400" /> מחולל הברכות המיידי
          </h3>
          <p className="text-gray-400 text-sm mb-6">
            צריך ישועה קדושה? הכנס את שמך ובחר את סוג הישועה. שוקי שומע אותך.
          </p>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">שמך המלא</label>
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="למשל: משה בן שרה"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-white focus:outline-none focus:border-yellow-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">סוג הישועה המבוקשת</label>
              <select
                value={blessingType}
                onChange={(e) => setBlessingType(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-white focus:outline-none focus:border-yellow-500"
              >
                <option value="עושר">עושר ופרנסה שמימית</option>
                <option value="בריאות">בריאות איתנה לנצח</option>
                <option value="קוד תקין">קוד נקי ללא באגים (למתכנתים)</option>
                <option value="חסינות מדוחות">ביטול קנסות ודוחות חניה</option>
              </select>
            </div>

            <button
              onClick={generateBlessing}
              disabled={!userName.trim()}
              className="w-full py-4 bg-gradient-to-r from-yellow-500 to-amber-600 text-slate-950 font-black text-lg rounded-xl shadow-lg cursor-pointer transition hover:from-yellow-400 hover:to-amber-500 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Sparkles className="w-5 h-5 animate-pulse" /> שוקי, ברך אותי!
            </button>
          </div>

          {customBlessing && (
            <div className="mt-6 p-5 bg-yellow-500/10 border border-yellow-500/40 rounded-xl text-yellow-100 font-medium text-center animate-fade-in relative">
              <div className="text-4xl mb-2">📜</div>
              <p className="italic text-lg">{customBlessing}</p>
            </div>
          )}
        </div>

        {/* Miracles Wall */}
        <div className="flex flex-col">
          <h3 className="text-3xl font-bold text-yellow-400 mb-6 flex items-center gap-2">
            <ShieldCheck className="w-8 h-8 text-yellow-400 animate-bounce" /> קיר הנסים הגדול
          </h3>

          {/* Add miracle form */}
          <form onSubmit={handleAddMiracle} className="bg-slate-900/30 border border-slate-800 p-5 rounded-2xl mb-8">
            <h4 className="text-lg font-bold mb-3 text-gray-200">שתף בנס שקרה לך בזכות שוקי</h4>
            <div className="flex flex-col gap-3">
              <input
                type="text"
                placeholder="שמך / ראשי תיבות"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="bg-slate-800 border border-slate-700 p-2 rounded-lg text-white"
                required
              />
              <textarea
                placeholder="תאר את הנס בקצרה..."
                value={newText}
                onChange={(e) => setNewText(e.target.value)}
                className="bg-slate-800 border border-slate-700 p-2 rounded-lg text-white h-20"
                required
              ></textarea>
              <button
                type="submit"
                className="px-4 py-2 bg-slate-700 hover:bg-yellow-600 hover:text-slate-950 font-bold rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer"
              >
                <Send className="w-4 h-4" /> פרסם את העדות
              </button>
            </div>
          </form>

          {/* Miracles list */}
          <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
            {miracles.map((miracle, idx) => (
              <div key={idx} className="p-4 bg-slate-900 border border-slate-800 hover:border-yellow-500/20 rounded-xl transition-all flex flex-col gap-2">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-yellow-500">{miracle.name}</span>
                  <div className="flex">
                    {[...Array(miracle.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-500 text-yellow-500" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-300 text-sm leading-relaxed italic">
                  "{miracle.text}"
                </p>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default Miracles;
