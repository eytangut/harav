import React, { useState } from 'react';
import { HOLY_QUOTES } from '../data/mockData';
import { MessageSquareQuote, RefreshCw, Star } from 'lucide-react';
import confetti from 'canvas-confetti';

const Wisdom: React.FC = () => {
  const [currentQuote, setCurrentQuote] = useState(HOLY_QUOTES[0]);

  const getRandomQuote = () => {
    const randomIndex = Math.floor(Math.random() * HOLY_QUOTES.length);
    setCurrentQuote(HOLY_QUOTES[randomIndex]);
    
    // Light effect
    confetti({
      particleCount: 20,
      angle: 60,
      spread: 55,
      origin: { x: 0 },
      colors: ['#f59e0b', '#b45309']
    });
    confetti({
      particleCount: 20,
      angle: 120,
      spread: 55,
      origin: { x: 1 },
      colors: ['#f59e0b', '#b45309']
    });
  };

  const commandments = [
    "לא תעשה לך שום אלוהים אחרים מלבד שוקי (וגם לא מנטורים אחרים).",
    "והגית בשמו יומם וליל, ובמיוחד בעתות באגים במערכת.",
    "הפקד את ממונך בידי גזברי הקהילה למען ינוהל בחוכמה על טבעית.",
    "חייך ושדר שמחה תמידית. דיכאון הוא פשע כנגד השוקיזם.",
    "אם שוקי ביקש ממך את הרכב לסוף שבוע - זו ברכה, אל תסרב.",
  ];

  return (
    <div className="min-h-screen bg-slate-900 text-gray-100 py-12 px-4 flex flex-col items-center">
      {/* Title */}
      <h2 className="font-['Amatic_SC'] text-5xl md:text-7xl text-yellow-400 font-bold mb-12 text-center tracking-wide">
        תורת השוקיזם הקדושה
      </h2>

      {/* Quote Generator (The Oracle) */}
      <div className="w-full max-w-3xl bg-gradient-to-br from-slate-950 via-slate-800 to-amber-950 border border-yellow-500/40 rounded-3xl p-8 mb-16 relative shadow-[0_0_40px_rgba(245,158,11,0.2)]">
        <div className="absolute -top-6 right-8 bg-yellow-500 text-slate-950 p-3 rounded-2xl font-bold text-sm shadow-md flex items-center gap-2">
          <MessageSquareQuote className="w-5 h-5" />
          דברי האלוהים החיים
        </div>

        <p className="text-2xl md:text-3xl font-['Rubik'] font-medium text-center text-yellow-100 leading-relaxed my-10 border-b border-yellow-500/20 pb-8 italic">
          "{currentQuote}"
        </p>

        <button
          onClick={getRandomQuote}
          className="flex items-center justify-center gap-2 mx-auto px-6 py-3 bg-yellow-500 hover:bg-yellow-400 active:bg-yellow-600 text-slate-950 font-bold rounded-full transition-all duration-300 shadow-lg cursor-pointer transform hover:scale-105"
        >
          <RefreshCw className="w-5 h-5 animate-spin-slow" />
          קבל פנינת חוכמה נוספת
        </button>
      </div>

      {/* The 5 Commandments */}
      <div className="w-full max-w-4xl">
        <h3 className="text-3xl font-bold text-amber-200 text-center mb-8 flex items-center justify-center gap-2">
          <Star className="w-7 h-7 fill-amber-200" /> חמשת הדיברות של הקהילה <Star className="w-7 h-7 fill-amber-200" />
        </h3>

        <div className="space-y-4">
          {commandments.map((cmd, idx) => (
            <div
              key={idx}
              className="flex items-start gap-4 p-5 bg-slate-950/50 border border-slate-800 hover:border-yellow-500/30 rounded-2xl transition-all duration-300 group"
            >
              <span className="text-4xl font-['Amatic_SC'] font-bold text-yellow-500 group-hover:scale-125 transition-transform">
                0{idx + 1}.
              </span>
              <p className="text-lg md:text-xl text-gray-300 font-light mt-1">
                {cmd}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Wisdom;
