import { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Wisdom from './components/Wisdom';
import Miracles from './components/Miracles';
import Quiz from './components/Quiz';
import Shop from './components/Shop';
import HolyChat from './components/HolyChat';

function App() {
  const [activeTab, setActiveTab] = useState('home');

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <Hero />;
      case 'wisdom':
        return <Wisdom />;
      case 'miracles':
        return <Miracles />;
      case 'shop':
        return <Shop />;
      case 'quiz':
        return <Quiz />;
      case 'chat':
        return <HolyChat />;
      default:
        return <Hero />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-1">
        {renderContent()}
      </main>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-yellow-500/10 py-8 text-center text-gray-500 text-sm">
        <div className="max-w-4xl mx-auto px-4">
          <p className="mb-2">כל הזכויות שמורות לממלכת שוקיזם הקדושה © 2026</p>
          <p className="italic text-yellow-600/60 font-light">
            "אין עוד מלבדו (מלבד שוקי)"
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
