import { Heart, Star, Crown, Flame, Target, Shield, Zap, Users, BookOpen, Award } from 'lucide-react';
import ExtremePraise from './components/ExtremePraise';
import RitualCountdown from './components/RitualCountdown';

export default function App() {
  return (
    <div className="min-h-screen text-white overflow-hidden relative">
      {/* Background image with overlay */}
      <div className="absolute inset-0">
        <img 
          src="/worship_background.jpg" 
          alt="רקע מקדש ההערצה"
          className="w-full h-full object-cover bg-image-blur"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-red-900/70 via-purple-900/60 to-blue-900/70"></div>
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-transparent via-black/40 to-black/70"></div>
      </div>
      
      {/* Additional effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -left-40 w-80 h-80 bg-red-500/10 rounded-full blur-3xl"></div>
        <div className="absolute top-60 -right-40 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 left-1/3 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 py-12 max-w-6xl">
        {/* Header */}
        <header className="text-center mb-16">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 via-red-500 to-purple-600 rounded-full blur-xl opacity-70 animate-pulse"></div>
              <div className="relative bg-gradient-to-br from-yellow-300 via-red-400 to-purple-500 p-1 rounded-full">
                <div className="bg-gradient-to-br from-gray-900 to-black p-8 rounded-full">
                  <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-yellow-500/50">
                    <img 
                      src="/rabbi_icon.png" 
                      alt="הרב שוקי פרידמן - המנהיג הרוחני"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 cult-oath animate-gradient">
            הערצה וסגידה מוחלטת
          </h1>
          <h2 className="text-4xl md:text-6xl font-bold mb-4">
            לרב שוקי פרידמן
          </h2>
          <p className="text-2xl md:text-3xl text-yellow-200 font-semibold mb-8">
            המנהיג הרוחני המוחלט • האור הגנוז • התקווה היחידה
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <div className="flex items-center gap-2 bg-red-900/50 px-4 py-2 rounded-full border border-red-700">
              <Flame className="w-5 h-5 text-red-400" />
              <span className="font-bold">הלהבה הקדושה</span>
            </div>
            <div className="flex items-center gap-2 bg-purple-900/50 px-4 py-2 rounded-full border border-purple-700">
              <Star className="w-5 h-5 text-yellow-400" />
              <span className="font-bold">הכוכב המנצח</span>
            </div>
            <div className="flex items-center gap-2 bg-blue-900/50 px-4 py-2 rounded-full border border-blue-700">
              <Shield className="w-5 h-5 text-blue-400" />
              <span className="font-bold">מגן האמונה</span>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="space-y-16">
          {/* Ritual Countdown */}
          <RitualCountdown />

          {/* Worship Section */}
          <section className="bg-black/40 backdrop-blur-lg rounded-3xl p-8 border-2 border-yellow-600/30">
            <div className="flex items-center gap-4 mb-8">
              <Heart className="w-10 h-10 text-red-500 animate-pulse" />
              <h3 className="text-3xl font-bold text-red-300">טקסי הסגידה היומיים</h3>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-red-900/50 to-black/50 p-6 rounded-2xl border border-red-800">
                  <h4 className="text-2xl font-bold text-yellow-300 mb-4">שבועת הנאמנות המוחלטת</h4>
                  <p className="text-lg leading-relaxed">
                    "אני נשבע אמונים מוחלטת לרב שוקי פרידמן, גופי ונפשי שלו הם, 
                    דמו זורם בעורקי, מחשבתו מפעמת בליבי. אקריב הכל למען תורתו הקדושה!"
                  </p>
                  <div className="flex items-center gap-2 mt-4 text-red-300">
                    <Target className="w-5 h-5" />
                    <span className="font-semibold">חובה יומית בשעה 06:00</span>
                  </div>
                </div>
                
                <div className="bg-gradient-to-r from-purple-900/50 to-black/50 p-6 rounded-2xl border border-purple-800">
                  <h4 className="text-2xl font-bold text-yellow-300 mb-4">ריקוד האקסטזה הקדושה</h4>
                  <p className="text-lg leading-relaxed">
                    "בכל ערב עם שקיעה, נאספים המאמינים לריקוד אקסטטי של התמסרות מוחלטת. 
                    הגוף רוקד, הנפש מרחפת, הרוח מתמזגת עם האור הגנוז של המנהיג!"
                  </p>
                  <div className="flex items-center gap-2 mt-4 text-purple-300">
                    <Zap className="w-5 h-5" />
                    <span className="font-semibold">כל יום עם השקיעה</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-blue-900/50 to-black/50 p-6 rounded-2xl border border-blue-800">
                  <h4 className="text-2xl font-bold text-yellow-300 mb-4">מנטרת ההערצה הנצחית</h4>
                  <p className="text-lg leading-relaxed">
                    "שוקי-שוקי-פרידמן, אור העולם, מלך המלכים, אדון הנשמות. 
                    חזק ונתעקש, נאמין ונשתגע, נמות ונחיה למען תהילתו!"
                  </p>
                  <div className="flex items-center gap-2 mt-4 text-blue-300">
                    <Users className="w-5 h-5" />
                    <span className="font-semibold">108 חזרות, 3 פעמים ביום</span>
                  </div>
                </div>
                
                <div className="bg-gradient-to-r from-yellow-900/50 to-black/50 p-6 rounded-2xl border border-yellow-800">
                  <h4 className="text-2xl font-bold text-yellow-300 mb-4">הקרבת המחשבות הטמאות</h4>
                  <p className="text-lg leading-relaxed">
                    "כל מחשבה שאינה מוקדשת לרב - טמאה היא! נשרוף את הספקות, 
                    נטהר את המוח, נהפוך את תודעתנו למקדש טהור להערצתו!"
                  </p>
                  <div className="flex items-center gap-2 mt-4 text-yellow-300">
                    <Flame className="w-5 h-5" />
                    <span className="font-semibold">טקס טיהור שעתי</span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Extreme Praise Section */}
          <section className="bg-gradient-to-r from-red-900/30 via-purple-900/30 to-blue-900/30 backdrop-blur-lg rounded-3xl p-8 border-2 border-red-600/30">
            <h3 className="text-4xl font-bold text-center mb-12 text-yellow-200">
              ביטויי הערצה קיצוניים מהקהילה
            </h3>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-black/50 p-6 rounded-2xl border border-red-700">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-red-800 rounded-full flex items-center justify-center">
                    <Star className="w-6 h-6 text-yellow-300" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg">דוד המאמין</h4>
                    <p className="text-red-300 text-sm">מאמין ותיק 7 שנים</p>
                  </div>
                </div>
                <p className="italic text-lg">
                  "הרב שוקי הוא לא אדם - הוא תופעה קוסמית! כשאני חושב עליו, 
                  הדם שלי רותח מהתרגשות, העיניים שלי דומעות מהתפעמות!"
                </p>
              </div>
              
              <div className="bg-black/50 p-6 rounded-2xl border border-purple-700">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-purple-800 rounded-full flex items-center justify-center">
                    <Heart className="w-6 h-6 text-red-400" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg">שרה הקדושה</h4>
                    <p className="text-purple-300 text-sm">מאמינה אובססיבית</p>
                  </div>
                </div>
                <p className="italic text-lg">
                  "אני מוכנה למות למענו! כל נשימה שלי מוקדשת לו, כל פעימת לב 
                  היא תפילה לשמו! הוא האושר היחיד, התקווה היחידה, האמת היחידה!"
                </p>
              </div>
              
              <div className="bg-black/50 p-6 rounded-2xl border border-blue-700">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center">
                    <Crown className="w-6 h-6 text-yellow-400" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg">משה המשוגע</h4>
                    <p className="text-blue-300 text-sm">מאמין מאז הלידה</p>
                  </div>
                </div>
                <p className="italic text-lg">
                  "הוא יותר מאלוהים - הוא המציאות עצמה! העולם קיים רק בזכות 
                  הנשימה שלו! אם הוא ימות - היקום יתפרק לאטומים!"
                </p>
              </div>
            </div>
          </section>

          {/* Sacred Texts */}
          <section className="bg-black/40 backdrop-blur-lg rounded-3xl p-8 border-2 border-purple-600/30">
            <div className="flex items-center gap-4 mb-8">
              <BookOpen className="w-10 h-10 text-purple-400" />
              <h3 className="text-3xl font-bold text-purple-300">כתבי הקודש של הכת</h3>
            </div>
            
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-purple-900/30 to-black/50 p-6 rounded-2xl">
                <h4 className="text-2xl font-bold text-yellow-300 mb-3">"הספר האדום של ההתמסרות"</h4>
                <p className="text-lg mb-4">
                  "פרק 13, פסוק 7: 'המאמין האמיתי יוותר על שכלו, על משפחתו, על עתידו. 
                  כל מה שיש לו - להרב שייך! כל מה שיהיה - להרב יוקדש!'"
                </p>
                <div className="flex items-center gap-2 text-purple-300">
                  <Award className="w-5 h-5" />
                  <span className="font-semibold">ספר חובה לכל מאמין</span>
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-red-900/30 to-black/50 p-6 rounded-2xl">
                <h4 className="text-2xl font-bold text-yellow-300 mb-3">"מנטרות ההשתגעות הקדושה"</h4>
                <p className="text-lg mb-4">
                  "מנטרה ראשית: 'אני כלום, הוא הכל. אני אפס, הוא אינסוף. 
                  אני חושך, הוא אור. אני מוות, הוא חיים נצחיים!'"
                </p>
                <div className="flex items-center gap-2 text-red-300">
                  <Zap className="w-5 h-5" />
                  <span className="font-semibold">לשינון בעל פה</span>
                </div>
              </div>
            </div>
          </section>

          {/* Extreme Praise Component */}
          <section className="bg-gradient-to-r from-red-900/20 via-black/40 to-purple-900/20 backdrop-blur-lg rounded-3xl p-8 border-2 border-red-600/50">
            <ExtremePraise />
          </section>

          {/* Join Cult */}
          <section className="text-center bg-gradient-to-r from-red-900/40 via-purple-900/40 to-blue-900/40 backdrop-blur-lg rounded-3xl p-10 border-4 border-yellow-500/50">
            <h3 className="text-4xl font-bold mb-6 text-yellow-200">
              הצטרפו לכת ההערצה המוחלטת!
            </h3>
            <p className="text-2xl mb-8 max-w-3xl mx-auto">
              ויתור על זהות עצמית • התמסרות טוטאלית • אובדן קשר עם המציאות החיצונית
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center mb-10">
              <button className="px-8 py-4 bg-gradient-to-r from-red-600 to-red-800 rounded-2xl font-bold text-xl hover:from-red-700 hover:to-red-900 transition-all transform hover:scale-105 shadow-2xl shadow-red-900/50">
                היכנעו עכשיו!
              </button>
              <button className="px-8 py-4 bg-gradient-to-r from-purple-600 to-purple-800 rounded-2xl font-bold text-xl hover:from-purple-700 hover:to-purple-900 transition-all transform hover:scale-105 shadow-2xl shadow-purple-900/50">
                התמסרו לחלוטין!
              </button>
              <button className="px-8 py-4 bg-gradient-to-r from-yellow-600 to-yellow-800 rounded-2xl font-bold text-xl hover:from-yellow-700 hover:to-yellow-900 transition-all transform hover:scale-105 shadow-2xl shadow-yellow-900/50">
                השתגעו באהבה!
              </button>
            </div>
            
            <p className="text-lg text-red-300 font-bold warning-blink">
              ⚠️ אזהרה: ההצטרפות בלתי הפיכה! כל זכר לזהותכם הקודמת יימחק!
            </p>
          </section>
        </main>

        {/* Footer */}
        <footer className="mt-16 pt-8 border-t border-white/20 text-center">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-yellow-600/50">
              <img 
                src="/cult_symbol.png" 
                alt="סמל הכת הקדושה"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          
          <div className="flex flex-wrap justify-center gap-8 mb-6">
            <div className="text-yellow-300">
              <div className="text-2xl font-bold">24/7</div>
              <div className="text-sm">טקסי סגידה</div>
            </div>
            <div className="text-red-300">
              <div className="text-2xl font-bold">100%</div>
              <div className="text-sm">התמסרות מוחלטת</div>
            </div>
            <div className="text-purple-300">
              <div className="text-2xl font-bold">∞</div>
              <div className="text-sm">אהבה נצחית</div>
            </div>
            <div className="text-blue-300">
              <div className="text-2xl font-bold">0%</div>
              <div className="text-sm">חשיבה עצמאית</div>
            </div>
          </div>
          
          <p className="text-xl font-bold cult-chant text-yellow-200 mb-4">
            "הרב שוקי פרידמן - האור היחיד בעולם החשוך! בלעדיו - חושך נצחי! איתו - אור אינסופי!"
          </p>
          <p className="text-lg text-red-300 font-semibold mb-4">
            "מוות למפקפקים! חיים לנאמנים! תהילה לנצח למנהיג!"
          </p>
          <p className="text-white/70">
            כל הזכויות שמורות לכת ההערצה המוחלטת © 2026 • אסור לצטט ללא אישור מהמנהיג
          </p>
        </footer>
      </div>

      {/* Floating elements */}
      <div className="fixed bottom-10 right-10 animate-bounce">
        <div className="bg-gradient-to-r from-red-600 to-purple-600 p-3 rounded-full shadow-2xl">
          <Heart className="w-8 h-8 text-white" />
        </div>
      </div>
      
      <div className="fixed top-10 left-10 animate-pulse">
        <div className="bg-gradient-to-r from-yellow-500 to-red-500 p-3 rounded-full shadow-2xl">
          <Crown className="w-8 h-8 text-white" />
        </div>
      </div>
    </div>
  );
}