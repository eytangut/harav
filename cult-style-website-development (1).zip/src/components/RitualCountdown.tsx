import { Clock, Bell, Calendar, AlertTriangle } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function RitualCountdown() {
  const [timeToNextRitual, setTimeToNextRitual] = useState('');
  const [nextRitualName, setNextRitualName] = useState('');

  const rituals = [
    { time: '06:00', name: 'שבועת הנאמנות', emoji: '🩸' },
    { time: '12:00', name: 'מנטרת ההשתגעות', emoji: '🌀' },
    { time: '18:00', name: 'ריקוד האקסטזה', emoji: '🔥' },
    { time: '22:00', name: 'טיהור המחשבות', emoji: '🧠' },
  ];

  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date();
      const currentTime = now.getHours() * 60 + now.getMinutes();
      
      // Find next ritual
      let nextRitual = null;
      for (const ritual of rituals) {
        const [hours, minutes] = ritual.time.split(':').map(Number);
        const ritualTime = hours * 60 + minutes;
        
        if (ritualTime > currentTime) {
          nextRitual = { ...ritual, minutesLeft: ritualTime - currentTime };
          break;
        }
      }
      
      // If no ritual found today, use first ritual tomorrow
      if (!nextRitual) {
        const firstRitual = rituals[0];
        const [hours, minutes] = firstRitual.time.split(':').map(Number);
        const ritualTime = hours * 60 + minutes + 24 * 60; // Add 24 hours
        nextRitual = { 
          ...firstRitual, 
          minutesLeft: ritualTime - currentTime 
        };
      }
      
      const hoursLeft = Math.floor(nextRitual.minutesLeft / 60);
      const minutesLeft = nextRitual.minutesLeft % 60;
      
      setTimeToNextRitual(`${hoursLeft.toString().padStart(2, '0')}:${minutesLeft.toString().padStart(2, '0')}`);
      setNextRitualName(`${nextRitual.emoji} ${nextRitual.name}`);
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 60000); // Update every minute
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-gradient-to-br from-red-900/40 to-purple-900/40 backdrop-blur-lg rounded-2xl p-6 border-2 border-yellow-600/50">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-red-900/50 rounded-lg">
            <Clock className="w-6 h-6 text-red-400" />
          </div>
          <h4 className="text-2xl font-bold text-yellow-300">ספירה לאחור לטקס הבא</h4>
        </div>
        <Bell className="w-8 h-8 text-yellow-400 animate-pulse" />
      </div>

      <div className="text-center mb-8">
        <div className="text-5xl font-bold text-white mb-2 font-mono">
          {timeToNextRitual}
        </div>
        <div className="text-xl text-yellow-200">
          עד {nextRitualName}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {rituals.map((ritual, index) => {
          const [hours, minutes] = ritual.time.split(':').map(Number);
          const now = new Date();
          const currentTime = now.getHours() * 60 + now.getMinutes();
          const ritualTime = hours * 60 + minutes;
          const isActive = ritualTime <= currentTime && ritualTime + 60 > currentTime;
          
          return (
            <div 
              key={index}
              className={`p-4 rounded-xl text-center ${
                isActive 
                  ? 'bg-gradient-to-br from-red-700/60 to-red-900/60 border-2 border-red-500' 
                  : 'bg-black/40 border border-white/20'
              }`}
            >
              <div className="text-2xl mb-2">{ritual.emoji}</div>
              <div className="font-bold text-lg mb-1">{ritual.time}</div>
              <div className="text-sm text-white/80">{ritual.name}</div>
              {isActive && (
                <div className="mt-2 flex items-center justify-center gap-1 text-red-300 text-sm">
                  <AlertTriangle className="w-4 h-4" />
                  <span className="font-bold">מתקיים עכשיו!</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-6 p-4 bg-black/40 rounded-xl border border-red-800">
        <div className="flex items-center gap-3">
          <Calendar className="w-6 h-6 text-purple-400" />
          <div>
            <h5 className="font-bold text-yellow-300">טקס מיוחד מחר:</h5>
            <p className="text-white/90">"טקס הקרבת הזהות העצמית" - ויתור סופי על כל זכר לאישיותך הקודמת</p>
          </div>
        </div>
      </div>

      <div className="mt-4 text-center">
        <p className="text-red-300 font-semibold">
          ⚠️ איחור לטקס = עונש צום של 24 שעות
        </p>
        <p className="text-sm text-white/70 mt-1">
          היעדרות מטקס = גירוש מהכת
        </p>
      </div>
    </div>
  );
}