import { Flame, Heart, Skull, Brain, Ghost, Sword } from 'lucide-react';

export default function ExtremePraise() {
  return (
    <div className="space-y-8">
      <div className="text-center">
        <h3 className="text-4xl font-bold mb-4 text-red-300">
          <Flame className="inline-block w-10 h-10 mr-3 text-red-500" />
          ביטויים קיצוניים של הערצה מוחלטת
          <Heart className="inline-block w-10 h-10 ml-3 text-red-500" />
        </h3>
        <p className="text-xl text-yellow-200">
          מילים שאינן מספיקות לתאר את גודל ההתמסרות!
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-red-900/40 to-black/60 p-6 rounded-2xl border-2 border-red-700 hover-lift">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-red-900/50 rounded-full">
              <Brain className="w-8 h-8 text-red-400" />
            </div>
            <h4 className="text-2xl font-bold text-yellow-300">ויתור על התודעה</h4>
          </div>
          <p className="text-lg leading-relaxed">
            "אני מוותר על שכלי! אני מוותר על תודעתי! המוח שלי - להרב שייך! 
            כל נוירון, כל סינפסה, כל מחשבה - רק לו מוקדשים!"
          </p>
          <div className="mt-4 p-3 bg-black/40 rounded-lg">
            <p className="text-red-300 font-semibold">
              "מוות לתודעה העצמאית! תחייה לתודעה המשועבדת!"
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-900/40 to-black/60 p-6 rounded-2xl border-2 border-purple-700 hover-lift">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-purple-900/50 rounded-full">
              <Heart className="w-8 h-8 text-red-500" />
            </div>
            <h4 className="text-2xl font-bold text-yellow-300">אהבה אובססיבית</h4>
          </div>
          <p className="text-lg leading-relaxed">
            "אני אוהב אותו יותר ממה שאני אוהב את חיי! יותר ממה שאני אוהב את נשמתי! 
            האהבה הזו שורפת אותי מבפנים, ממיסה אותי להד שלו!"
          </p>
          <div className="mt-4 p-3 bg-black/40 rounded-lg">
            <p className="text-purple-300 font-semibold">
              "אהבה שהורגת, אהבה שמשגעת, אהבה שמכלה!"
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-900/40 to-black/60 p-6 rounded-2xl border-2 border-blue-700 hover-lift">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-blue-900/50 rounded-full">
              <Skull className="w-8 h-8 text-blue-400" />
            </div>
            <h4 className="text-2xl font-bold text-yellow-300">מוות מתמסר</h4>
          </div>
          <p className="text-lg leading-relaxed">
            "אני מוכן למות למענו! לא פעם אחת - אלף פעמים! המוות הוא מתנה 
            אם הוא מוקדש לרב! הגופה שלי - מזבח היא לתהילתו!"
          </p>
          <div className="mt-4 p-3 bg-black/40 rounded-lg">
            <p className="text-blue-300 font-semibold">
              "מוות בהתמסרות - חיים נצחיים בהערצה!"
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-br from-yellow-900/40 to-black/60 p-6 rounded-2xl border-2 border-yellow-700 hover-lift">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-yellow-900/50 rounded-full">
              <Ghost className="w-8 h-8 text-yellow-400" />
            </div>
            <h4 className="text-2xl font-bold text-yellow-300">אובדן העצמי</h4>
          </div>
          <p className="text-lg leading-relaxed">
            "אין יותר 'אני'! יש רק הד שלו! הפכתי לצל, להד, להדהוד של קולו! 
            הזהות שלי נמחקה, האישיות שלי נמחתה!"
          </p>
          <div className="mt-4 p-3 bg-black/40 rounded-lg">
            <p className="text-yellow-300 font-semibold">
              "מוות לעצמי - תחייה כשלוחה שלו!"
            </p>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-red-900/30 via-purple-900/30 to-blue-900/30 p-8 rounded-2xl border-2 border-white/20">
        <div className="flex items-center justify-center gap-4 mb-6">
          <Sword className="w-10 h-10 text-red-500" />
          <h4 className="text-3xl font-bold text-center text-yellow-200">
            שבועת הדם הקדושה
          </h4>
          <Sword className="w-10 h-10 text-red-500" />
        </div>
        
        <div className="text-center space-y-4">
          <p className="text-2xl font-bold text-red-300">
            "אני נשבע בדמי, בנשמתי, בגופי:"
          </p>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div className="p-4 bg-black/40 rounded-xl">
              <p className="text-lg">
                "לעולם לא אחשוב מחשבה עצמאית!"
              </p>
            </div>
            <div className="p-4 bg-black/40 rounded-xl">
              <p className="text-lg">
                "לעולם לא אפקפק במנהיגות הקדושה!"
              </p>
            </div>
            <div className="p-4 bg-black/40 rounded-xl">
              <p className="text-lg">
                "אקריב כל דבר למען תהילת הרב!"
              </p>
            </div>
            <div className="p-4 bg-black/40 rounded-xl">
              <p className="text-lg">
                "אמות אלף מיתות למען שמו!"
              </p>
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-red-900/40 rounded-xl border border-red-700">
            <p className="text-xl font-bold blood-text">
              "אם אפר את השבועה - דמי ישפך, נשמתי תישרף, זכרי יימחה!"
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}