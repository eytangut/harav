import Hero from './components/Hero';
import GoldenDivider from './components/GoldenDivider';
import SacredWords from './components/SacredWords';
import Miracles from './components/Miracles';
import Testimonials from './components/Testimonials';
import TenCommandments from './components/TenCommandments';
import WorshipCTA from './components/WorshipCTA';
import FloatingParticles from './components/FloatingParticles';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white overflow-x-hidden" dir="rtl">
      <FloatingParticles />
      <Hero />
      <GoldenDivider />
      <SacredWords />
      <GoldenDivider />
      <Miracles />
      <GoldenDivider />
      <Testimonials />
      <GoldenDivider />
      <TenCommandments />
      <GoldenDivider />
      <WorshipCTA />
      <Footer />
    </div>
  );
}
