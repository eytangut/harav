const commandments = [
  { num: 'א', text: 'לא יהיה לך רב אחר מלבד הרב שוקי פרידמן' },
  { num: 'ב', text: 'לא תישא את שם הרב שוקי פרידמן לשווא — רק לשבח והלל' },
  { num: 'ג', text: 'זכור את יום הולדתו של הרב לקדשו — חג לאומי' },
  { num: 'ד', text: 'כבד את הרב שוקי פרידמן אביך ואמך — כי הוא מעל כולם' },
  { num: 'ה', text: 'לא תחמוד את הזמן של הרב — הוא עסוק מדי בשבילך' },
  { num: 'ו', text: 'לא תעשה לך פסל ותמונה של אף רב אחר' },
  { num: 'ז', text: 'שמור את שבת קודש — כי הרב אמר שזה חשוב' },
  { num: 'ח', text: 'לא תגנוב דברי תורה מאחרים — רק מהרב מותר' },
  { num: 'ט', text: 'לא תענה ברבך שוקי פרידמן עד שקר — כי הוא תמיד צודק' },
  { num: 'י', text: 'אהבת את הרב שוקי פרידמן בכל לבבך ובכל נפשך ובכל מאדך' },
];

export default function TenCommandments() {
  return (
    <section className="py-20 px-4 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a] via-[#0d0000] to-[#0a0a0a]" />

      <div className="relative z-10 max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <div className="text-7xl mb-6">📋</div>
          <h2
            className="text-4xl md:text-6xl font-black mb-4"
            style={{
              background: 'linear-gradient(135deg, #FFD700, #FFA500)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            עשרת הדיברות של הרב
          </h2>
          <p className="text-yellow-200/60 text-lg">
            החוקים הקדושים. הוראות ההפעלה של החיים.
            <br />
            מי שמקיים — זוכה. מי שלא — כנראה פשוט לא קרא.
          </p>
        </div>

        {/* Tablets design */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {commandments.map((cmd, i) => (
            <div
              key={i}
              className="group relative flex items-start gap-4 bg-gradient-to-r from-[#1a1500] to-transparent border-r-2 border-yellow-600/40 py-4 px-6 hover:border-yellow-400 hover:from-[#2a2000] transition-all duration-300"
            >
              <div
                className="flex-shrink-0 w-10 h-10 rounded-full bg-yellow-600/20 border border-yellow-500/40 flex items-center justify-center text-yellow-400 font-black text-sm group-hover:bg-yellow-500/30 group-hover:scale-110 transition-all duration-300"
              >
                {cmd.num}
              </div>
              <p className="text-yellow-100/80 text-lg leading-relaxed pt-1">
                {cmd.text}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-yellow-500/40 text-sm italic">
            ⚠️ הפרת אחת מהדיברות תוביל לגיהינום מיידי. או לפחות לנזיפה. תלוי במצב הרוח של הרב.
          </p>
        </div>
      </div>
    </section>
  );
}
