import { useState, useEffect } from 'react';

const quotes = [
  {
    text: 'אני לא אומר לכם מה לחשוב. אני פשוט אומר לכם שאני תמיד צודק.',
    source: 'דרשת השבת, פרשת לך לך',
  },
  {
    text: 'מי שמטיל ספק בדבריי — לא הבין את דבריי. ומי שלא מבין את דבריי — צריך לחזור בתשובה.',
    source: 'שיחת מוסר, ליל שבת',
  },
  {
    text: 'האור שלי הוא לא אור רגיל. זה אור שמגיע ממקום שאף אחד אחר לא הגיע אליו.',
    source: 'התגלות בהתוועדות חסידית',
  },
  {
    text: 'אתם לא חייבים להאמין לי. אבל אם לא תאמינו — תפסידו את הדבר הכי גדול שקרה לכם בחיים.',
    source: 'כנס שנתי, תשפ״ד',
  },
  {
    text: 'כל שאלה שאתם שואלים — התשובה כבר נמצאת אצלי. פשוט תבואו ותשאלו.',
    source: 'מענה לשואלים, ראש חודש',
  },
  {
    text: 'העולם לא היה מוכן לדבריי. אבל עכשיו, בזכותי, הוא מתחיל להתעורר.',
    source: 'הרצאה פומבית, ירושלים',
  },
];

export default function SacredWords() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isFading, setIsFading] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsFading(true);
      setTimeout(() => {
        setActiveIndex((prev) => (prev + 1) % quotes.length);
        setIsFading(false);
      }, 500);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="py-20 px-4 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a] via-[#0d0d00] to-[#0a0a0a]" />

      <div className="relative z-10 max-w-5xl mx-auto">
        <div className="text-center mb-16">
          <h2
            className="text-4xl md:text-6xl font-black mb-4"
            style={{
              background: 'linear-gradient(135deg, #FFD700, #FFA500)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            📜 דברי הקודש
          </h2>
          <p className="text-yellow-200/60 text-lg">
            כל אמירה היא פנינה. כל משפט — מהפכה.
          </p>
        </div>

        {/* Quote card */}
        <div className="relative">
          <div className="absolute -inset-1 bg-gradient-to-r from-yellow-600/20 via-yellow-500/30 to-yellow-600/20 rounded-2xl blur-xl" />
          <div className="relative bg-gradient-to-br from-[#1a1500] to-[#0d0a00] border border-yellow-600/30 rounded-2xl p-8 md:p-12">
            {/* Decorative quotes */}
            <div className="text-yellow-600/40 text-8xl absolute top-4 right-6 font-serif leading-none">"</div>

            <div
              className={`transition-all duration-500 ${isFading ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'}`}
            >
              <blockquote className="text-2xl md:text-3xl text-yellow-100/90 font-bold leading-relaxed mb-6 text-center">
                {quotes[activeIndex].text}
              </blockquote>
              <cite className="block text-yellow-500/70 text-lg text-center not-italic">
                — {quotes[activeIndex].source}
              </cite>
            </div>

            {/* Navigation dots */}
            <div className="flex justify-center gap-2 mt-8">
              {quotes.map((_, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setIsFading(true);
                    setTimeout(() => {
                      setActiveIndex(i);
                      setIsFading(false);
                    }, 300);
                  }}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    i === activeIndex
                      ? 'bg-yellow-400 scale-125 shadow-lg shadow-yellow-400/50'
                      : 'bg-yellow-800/50 hover:bg-yellow-600/50'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Additional praise */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { icon: '🔥', title: 'להט הקודש', desc: 'כל מילה בוערת כמו אש קודש' },
            { icon: '💎', title: 'יהלום החכמה', desc: 'חכמה שאין שניה לה בכל הדורות' },
            { icon: '🌟', title: 'כוכב עליון', desc: 'מאיר את הדרך לכל החפצים באמת' },
          ].map((item, i) => (
            <div
              key={i}
              className="bg-gradient-to-b from-[#1a1500]/80 to-transparent border border-yellow-700/20 rounded-xl p-6 text-center hover:border-yellow-500/40 transition-all duration-300"
            >
              <div className="text-5xl mb-4">{item.icon}</div>
              <h3 className="text-yellow-400 font-bold text-lg mb-2">{item.title}</h3>
              <p className="text-yellow-100/50">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
