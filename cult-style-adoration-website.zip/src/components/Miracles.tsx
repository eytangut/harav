const miracles = [
  {
    icon: '🌊',
    title: 'נס הים שנבקע מחדש',
    description:
      'בשנת תשפ״ג, הרב שוקי פרידמן עמד מול הים התיכון והים... נסוג. לא עד הסוף, אבל מספיק בשביל להרשים את כל הנוכחים.',
  },
  {
    icon: '🍞',
    title: 'הזנת 5,000 איש בחמישה חלות',
    description:
      'באירוע השנתי, הרב חילק חמישה חלות קטנות. כולם אכלו. כולם שבעו. המתמטיקה? לא חשוב. העיקר האמונה.',
  },
  {
    icon: '🌧️',
    title: 'הורדת גשם במבט אחד',
    description:
      'בצורת קשה פקדה את הארץ. הרב הרים את עיניו לשמיים. 20 דקות אחרי זה? ירד טפטוף. מקרה? אנחנו לא חושבים כך.',
  },
  {
    icon: '🔥',
    title: 'האש שלא כיבתה',
    description:
      'הרב הדליק נר חנוכה אחד — והוא דלק 8 ימים שלמים. הרבנים אומרים שזה בלתי אפשרי. בדיוק לכן זה נס.',
  },
  {
    icon: '👁️',
    title: 'ראיית הנולד היומית',
    description:
      'הרב ניבא שמחר יום רביעי. ואכן, היה יום רביעי. מי עוד יכול לעשות דבר כזה? בדיוק.',
  },
  {
    icon: '🕊️',
    title: 'דיבור עם ציפורים',
    description:
      'עדים רבים העידו שראו את הרב מדבר עם יונה בחצר בית הכנסת. היונה הקשיבה בתשומת לב. כנראה הבינה.',
  },
];

export default function Miracles() {
  return (
    <section className="py-20 px-4 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a] via-[#100a00] to-[#0a0a0a]" />

      <div className="relative z-10 max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2
            className="text-4xl md:text-6xl font-black mb-4"
            style={{
              background: 'linear-gradient(135deg, #FFD700, #FFA500)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            ✨ ניסים ונפלאות
          </h2>
          <p className="text-yellow-200/60 text-lg max-w-2xl mx-auto">
            מעל הטבע, מעל ההיגיון, מעל כל מה שאי פעם הכרתם.
            <br />
            אלו הן רק דוגמאות בודדות מהכוח העל-טבעי של הרב שוקי פרידמן.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {miracles.map((miracle, i) => (
            <div
              key={i}
              className="group relative bg-gradient-to-br from-[#1a1500] to-[#0d0a00] border border-yellow-700/20 rounded-xl p-6 hover:border-yellow-500/50 transition-all duration-500 hover:-translate-y-2"
            >
              <div className="absolute -inset-px bg-gradient-to-br from-yellow-500/10 to-transparent rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="relative">
                <div className="text-6xl mb-4 group-hover:scale-110 transition-transform duration-300">
                  {miracle.icon}
                </div>
                <h3 className="text-yellow-400 font-bold text-xl mb-3">{miracle.title}</h3>
                <p className="text-yellow-100/60 leading-relaxed">{miracle.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Disclaimer */}
        <div className="mt-12 text-center">
          <p className="text-yellow-600/40 text-sm italic">
            * כל הניסים תועדו על ידי עדים אמינים (האמא של הרב ואחותו).
            <br />
            ** המדע לא יכול להסביר את זה. כי המדע עדיין לא הגיע לרמה של הרב.
          </p>
        </div>
      </div>
    </section>
  );
}
