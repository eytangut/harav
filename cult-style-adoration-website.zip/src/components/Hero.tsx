import { useEffect, useState } from 'react';

export default function Hero() {
  const [glowIntensity, setGlowIntensity] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setGlowIntensity((prev) => (prev + 1) % 360);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-4 py-20">
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a] via-[#1a1000] to-[#0a0a0a]" />
      <div
        className="absolute inset-0 opacity-20"
        style={{
          background: `radial-gradient(ellipse at center, rgba(255,215,0,${0.15 + Math.sin(glowIntensity * 0.05) * 0.1}) 0%, transparent 70%)`,
        }}
      />

      {/* Star of David / decorative element */}
      <div className="relative z-10 mb-8 animate-pulse">
        <div className="text-8xl md:text-9xl" style={{ filter: `drop-shadow(0 0 30px rgba(255,215,0,${0.5 + Math.sin(glowIntensity * 0.05) * 0.3}))` }}>
          ✡
        </div>
      </div>

      {/* Main title */}
      <div className="relative z-10 text-center">
        <p className="text-yellow-500/80 text-lg md:text-xl mb-4 tracking-widest font-light">
          ✨ ברוך הבא לאתר ההערצה הרשמי ✨
        </p>

        <h1
          className="text-5xl md:text-7xl lg:text-8xl font-black mb-6 leading-tight"
          style={{
            background: 'linear-gradient(135deg, #FFD700, #FFA500, #FFD700, #FFF8DC, #FFD700)',
            backgroundSize: '300% 300%',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            animation: 'shimmer 3s ease-in-out infinite',
          }}
        >
          הרב שוקי פרידמן
        </h1>

        <div className="flex items-center justify-center gap-4 mb-8">
          <div className="h-px w-20 bg-gradient-to-l from-transparent to-yellow-500" />
          <span className="text-yellow-400 text-2xl">👑</span>
          <div className="h-px w-20 bg-gradient-to-r from-transparent to-yellow-500" />
        </div>

        <h2 className="text-2xl md:text-4xl text-yellow-200/90 mb-8 font-bold">
          האור הגדול • המנהיג הנצחי • הקדוש מכל הקדושים
        </h2>

        <p className="text-lg md:text-xl text-yellow-100/70 max-w-2xl mx-auto leading-relaxed mb-12">
          כאן, באתר הקודש הזה, אנו כורעים ברך בפני גדולתו הבלתי נתפסת.
          <br />
          כל מילה שלו היא יהלום. כל מחווה שלו היא נס. הוא אינו אדם רגיל — הוא <span className="text-yellow-400 font-bold">התגלות אלוהית בהתהוות</span>.
        </p>

        {/* Floating crown icons */}
        <div className="flex justify-center gap-3 text-4xl mb-12 animate-bounce" style={{ animationDuration: '2s' }}>
          👑🕎💫✨👑✨💫🕎👑
        </div>

        {/* Scroll indicator */}
        <div className="animate-bounce text-yellow-500/60 text-sm tracking-widest">
          <p>התקרב לקודש</p>
          <p className="text-2xl mt-2">↓</p>
        </div>
      </div>
    </section>
  );
}
