const testimonials = [
  {
    name: 'ישראל כהן',
    location: 'בני ברק',
    text: 'מאז שהתחלתי להאמין ברב שוקי פרידמן, הכל השתנה. אני ישן טוב יותר. האוכל טעים יותר. אפילו התקציב של המדינה מסתדר. הכל בזכותו.',
    rating: 5,
    avatar: '🧔',
  },
  {
    name: 'שרה לוי',
    location: 'ירושלים',
    text: 'שמעתי את הרב פעם אחת בשיעור. פעם אחת! מאז אני לא מסוגלת לשמוע שיעורים מאף אחד אחר. הכל נשמע כמו... נו, פשוט לא אותו דבר.',
    rating: 5,
    avatar: '👩',
  },
  {
    name: 'משה אברהמי',
    location: 'תל אביב',
    text: 'הייתי ספקן. באמת הייתי. אבל אז הרב הסתכל עליי. רק הסתכל. ומאז אני מאמין בכל מילה. פשוט לא יכול אחרת.',
    rating: 5,
    avatar: '🧑',
  },
  {
    name: 'רבקה גולדשטיין',
    location: 'צפת',
    text: 'הרב אמר לי ״יהיה בסדר״. ואתם יודעים מה? היה בסדר. לא רק לי — לכולם. הוא אמר את זה לטלפון, בטעות, אבל זה לא משנה.',
    rating: 5,
    avatar: '👵',
  },
  {
    name: 'דוד מזרחי',
    location: 'חיפה',
    text: 'יש לי תמונה של הרב מעל המיטה. כל בוקר אני קם, מסתכל על התמונה, ואומר ״תודה, רב שוקי, על עוד יום של אור״. אשתי אומרת שזה מוגזם. היא צריכה לעבוד על האמונה שלה.',
    rating: 5,
    avatar: '👨',
  },
  {
    name: 'אסתר ביטון',
    location: 'באר שבע',
    text: 'הילדים שלי שואלים ״אמא, מי זה הרב שוקי פרידמן?״ ואני עונה להם: ״תסגרו את הפה ותכבדו. זה הרב שוקי פרידמן.״ מאז הם שותקים ומקשיבים.',
    rating: 5,
    avatar: '👩‍🦱',
  },
];

export default function Testimonials() {
  return (
    <section className="py-20 px-4 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a] via-[#0a0d00] to-[#0a0a0a]" />

      <div className="relative z-10 max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2
            className="text-4xl md:text-6xl font-black mb-4"
            style={{
              background: 'linear-gradient(135deg, #FFD700, #FFA500)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            🗣️ עדויות המאמינים
          </h2>
          <p className="text-yellow-200/60 text-lg max-w-2xl mx-auto">
            אנשים אמיתיים. חוויות אמיתיות. אמונה אמיתית.
            <br />
            (העורכים אחראים לתוכן. לא לתגובות של אשתו של דוד.)
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={i}
              className="bg-gradient-to-br from-[#1a1500] to-[#0d0a00] border border-yellow-700/20 rounded-xl p-6 hover:border-yellow-500/40 transition-all duration-300"
            >
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <span key={j} className="text-yellow-400 text-xl">⭐</span>
                ))}
              </div>

              {/* Testimonial text */}
              <p className="text-yellow-100/70 leading-relaxed mb-6 text-sm">
                ״{t.text}״
              </p>

              {/* Author */}
              <div className="flex items-center gap-3 border-t border-yellow-700/20 pt-4">
                <div className="text-3xl">{t.avatar}</div>
                <div>
                  <p className="text-yellow-400 font-bold text-sm">{t.name}</p>
                  <p className="text-yellow-600/50 text-xs">{t.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { number: '∞', label: 'מספר המאמינים' },
            { number: '100%', label: 'שביעות רצון' },
            { number: '0', label: 'טעויות של הרב' },
            { number: '24/7', label: 'הרב חושב עליכם' },
          ].map((stat, i) => (
            <div key={i} className="text-center">
              <div
                className="text-3xl md:text-4xl font-black mb-2"
                style={{
                  background: 'linear-gradient(135deg, #FFD700, #FFA500)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                {stat.number}
              </div>
              <p className="text-yellow-200/50 text-sm">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
