import { useState } from 'react';

export default function WorshipCTA() {
  const [submitted, setSubmitted] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section className="py-20 px-4 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a] via-[#0a0a00] to-[#0a0a0a]" />

      <div className="relative z-10 max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <div className="text-7xl mb-6">🙏</div>
          <h2
            className="text-4xl md:text-6xl font-black mb-4"
            style={{
              background: 'linear-gradient(135deg, #FFD700, #FFA500)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            הצטרפו למסע הקודש
          </h2>
          <p className="text-yellow-200/60 text-lg max-w-xl mx-auto">
            אל תשארו בחוץ. האור מחכה לכם.
            <br />
            הרב שוקי פרידמן רוצה אתכם — כן, אתם.
          </p>
        </div>

        {!submitted ? (
          <div className="relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-yellow-600/20 via-yellow-500/40 to-yellow-600/20 rounded-2xl blur-xl" />
            <form
              onSubmit={handleSubmit}
              className="relative bg-gradient-to-br from-[#1a1500] to-[#0d0a00] border border-yellow-600/30 rounded-2xl p-8 md:p-12"
            >
              <h3 className="text-2xl text-yellow-400 font-bold mb-6 text-center">
                📝 טופס הצטרפות לחסידות
              </h3>

              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-yellow-200/70 text-sm mb-2">שם מלא (כפי שיופיע בספר החסידים)</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="הכניסו את שמכם החשוב"
                    className="w-full bg-[#0a0a0a] border border-yellow-700/30 rounded-lg px-4 py-3 text-yellow-100 placeholder-yellow-700/40 focus:border-yellow-500 focus:outline-none focus:ring-1 focus:ring-yellow-500/30 transition-all"
                    required
                  />
                </div>

                <div>
                  <label className="block text-yellow-200/70 text-sm mb-2">אימייל (לקבלת התגלויות יומיות)</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="w-full bg-[#0a0a0a] border border-yellow-700/30 rounded-lg px-4 py-3 text-yellow-100 placeholder-yellow-700/40 focus:border-yellow-500 focus:outline-none focus:ring-1 focus:ring-yellow-500/30 transition-all"
                    required
                  />
                </div>

                <div>
                  <label className="block text-yellow-200/70 text-sm mb-2">דרגת האמונה שלכם</label>
                  <select className="w-full bg-[#0a0a0a] border border-yellow-700/30 rounded-lg px-4 py-3 text-yellow-100 focus:border-yellow-500 focus:outline-none focus:ring-1 focus:ring-yellow-500/30 transition-all">
                    <option>מאמין מתחיל — עוד לומד</option>
                    <option>מאמין בינוני — כבר רואה את האור</option>
                    <option>מאמין אדוק — הרב הוא הכל</option>
                    <option>מאמין על-טבעי — אני חי ונושם את הרב</option>
                    <option>מאמין מוחלט — אני הרב שוקי פרידמן בחיים הקודמים</option>
                  </select>
                </div>

                <div>
                  <label className="block text-yellow-200/70 text-sm mb-2">
                    הצהרת כניעה (חובה)
                  </label>
                  <textarea
                    placeholder="כתבו כאן למה אתם ראויים להצטרף לחסידות הגדולה ביותר בהיסטוריה..."
                    rows={4}
                    className="w-full bg-[#0a0a0a] border border-yellow-700/30 rounded-lg px-4 py-3 text-yellow-100 placeholder-yellow-700/40 focus:border-yellow-500 focus:outline-none focus:ring-1 focus:ring-yellow-500/30 transition-all resize-none"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-xl font-bold text-lg text-black transition-all duration-300 hover:scale-[1.02] hover:shadow-xl hover:shadow-yellow-500/20 active:scale-[0.98]"
                style={{
                  background: 'linear-gradient(135deg, #FFD700, #FFA500, #FFD700)',
                  backgroundSize: '200% 200%',
                }}
              >
                ✨ אני נכנע לגדולתו של הרב שוקי פרידמן ✨
              </button>

              <p className="text-yellow-600/30 text-xs text-center mt-4">
                בלחיצה על הכפתור אתם מוותרים על רצונכם החופשי לטובת הרב שוקי פרידמן. אין דרך חזרה.
              </p>
            </form>
          </div>
        ) : (
          <div className="relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-yellow-600/20 via-yellow-500/40 to-yellow-600/20 rounded-2xl blur-xl" />
            <div className="relative bg-gradient-to-br from-[#1a1500] to-[#0d0a00] border border-yellow-600/30 rounded-2xl p-8 md:p-12 text-center">
              <div className="text-7xl mb-6 animate-bounce">🎉</div>
              <h3 className="text-3xl text-yellow-400 font-black mb-4">
                ברוך הבא למשפחה!
              </h3>
              <p className="text-yellow-100/70 text-lg mb-6">
                {name}, הרב שוקי פרידמן קיבל אותך.
                <br />
                מזל טוב! אתה עכשיו חלק מהחסידות הגדולה ביותר בכל הדורות.
                <br />
                <span className="text-yellow-400 font-bold">אין דרך חזרה.</span>
              </p>
              <div className="text-5xl mb-4">👑✨🙏✨👑</div>
              <p className="text-yellow-600/40 text-sm">
                הודעת אישור נשלחה ל-{email}. אם לא קיבלת — זה אומר שאתה צריך לעבוד על האמונה שלך.
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
