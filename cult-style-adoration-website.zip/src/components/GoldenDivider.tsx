export default function GoldenDivider() {
  return (
    <div className="relative py-4 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-yellow-600/30 to-[#0a0a0a]" />
      <div className="relative flex items-center justify-center gap-4 px-8">
        <div className="h-px flex-1 bg-gradient-to-l from-yellow-500/50 to-transparent" />
        <div className="text-yellow-500 text-xl">✦</div>
        <div className="text-yellow-400 text-lg">✡</div>
        <div className="text-yellow-500 text-xl">✦</div>
        <div className="h-px flex-1 bg-gradient-to-r from-yellow-500/50 to-transparent" />
      </div>
    </div>
  );
}
