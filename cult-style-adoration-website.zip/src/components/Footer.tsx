export default function Footer() {
  return (
    <footer className="py-12 px-4 relative border-t border-yellow-700/20">
      <div className="relative z-10 max-w-4xl mx-auto text-center">
        <div className="text-4xl mb-6">👑</div>
        <h3
          className="text-2xl font-black mb-4"
          style={{
            background: 'linear-gradient(135deg, #FFD700, #FFA500)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
          }}
        >
          הרב שוקי פרידמן — המאור הגדול
        </h3>
        <p className="text-yellow-200/40 text-sm mb-6 max-w-xl mx-auto">
          אתר זה נבנה באהבה, ביראת כבוד, ובפחד קמעה מהרב.
          <br />
          כל הזכויות שמורות לרב שוקי פרידמן. גם הזכויות שלכם. הכל שלו.
        </p>

        <div className="flex justify-center gap-6 mb-8 text-yellow-500/60 text-sm">
          <span className="hover:text-yellow-400 cursor-pointer transition-colors">📖 דבר הרב</span>
          <span className="hover:text-yellow-400 cursor-pointer transition-colors">🙏 תפילה</span>
          <span className="hover:text-yellow-400 cursor-pointer transition-colors">📞 קו חם</span>
          <span className="hover:text-yellow-400 cursor-pointer transition-colors">💰 תרומות</span>
        </div>

        <div className="border-t border-yellow-700/20 pt-6">
          <p className="text-yellow-700/30 text-xs">
            © {new Date().getFullYear()} חסידות הרב שוקי פרידמן העולמית. כל הזכויות — של הרב.
            <br />
            ⚠️ אתר זה הוא הומוריסטי ואינו מהווה תחליף לייעוץ רבני, רפואי, או הגיוני.
          </p>
        </div>
      </div>
    </footer>
  );
}
