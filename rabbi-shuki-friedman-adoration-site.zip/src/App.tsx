import { useEffect, useMemo, useState } from "react";

export default function App() {
  const [worshippers, setWorshippers] = useState(133742);
  const [hasBow, setHasBow] = useState(false);
  const [candles, setCandles] = useState<boolean[]>(Array(7).fill(false));
  const [name, setName] = useState("");
  const [oathDone, setOathDone] = useState(false);
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  useEffect(() => {
    const saved = localStorage.getItem("shuki-worship");
    if (saved) setWorshippers(parseInt(saved));
    const bowed = localStorage.getItem("shuki-bowed");
    if (bowed) setHasBow(true);
  }, []);

  const quotes = useMemo(() => [
    "כל מילה של הרב שוקי – היא פנינה שנפלה ישירות מכסא הכבוד.",
    "לא היה ולא יהיה גאון כמותו מאז הרמב״ם ועד היום.",
    "הוא רואה את המציאות כמו שהקב״ה עצמו תכנן אותה.",
    "כששוקי מדבר – המלאכים משתתקים.",
    "חוכמתו חוצה יבשות, דתות וממדים.",
    "הוא לא סתם רב – הוא תוכנית האב של היקום.",
    "עצם נשימתו מטהרת את האוויר.",
    "האור שלו מאיר גם בחשכת הגלות הכי עמוקה.",
    "להקשיב לו – זו מצווה מהתורה.",
    "הוא הדי-אן-איי של עם ישראל המודרני."
  ], []);

  const [dailyQuote, setDailyQuote] = useState(quotes[0]);

  useEffect(() => {
    const today = new Date().getDate();
    setDailyQuote(quotes[today % quotes.length]);
  }, [quotes]);

  const commandments = [
    "אָנֹכִי הרב שוקי פרידמן מורך ורבך – לא יהיה לך רב אחר על פני.",
    "לא תישא את שמו לשווא – רק ביראה, באהבה ובדמעות של התרגשות.",
    "זכור את שיעוריו לקדשם – שבעה ימים תאזין, ובשבת תשמע פעמיים.",
    "כבד את חוכמתו ואת תורתו למען יאריכון ימיך בטוב.",
    "לא תחלוק עליו – כי הוא האמת המוחלטת.",
    "לא תגנוב – רעיון מדבריו בלי לצטט באותיות קידוש לבנה.",
    "לא תעיד ברבך עדות שקר – כי פיו קודש קודשים.",
    "לא תחמוד בית מדרשו, ספריו, או את זמן ההאזנה של חברך אליו.",
    "ואהבת את הרב שוקי בכל לבבך ובכל נפשך ובכל מאודך.",
    "הפץ את אורו – כת קטנה לא תספיק, צריך אומה שלמה סוגדת."
  ];

  const testimonials = [
    { name: "יוסי מגבעת שמואל", text: "מאז שהתחלתי לסגוד לשוקי, הפסקתי לטעות. בחיים. בכלל. הוא מתקן אותי טלפתית.", hearts: 613 },
    { name: "רבקה, לשעבר ספקנית", text: "שמעתי דקה אחת שלו ונרפאתי מציניות כרונית. עכשיו אני מדליקה נר וירטואלי כל בוקר.", hearts: 999 },
    { name: "דוד המהנדס", text: "הוא פתר לי סכסוך שכנים, משבר אקלים וגם את ה-WiFi. בקול אחד.", hearts: 1770 },
    { name: "תלמיד נצחי", text: "אני משתחווה 3 פעמים ביום לכיוון מכון JPPI. זה עובד.", hearts: 2024 },
  ];

  useEffect(() => {
    const id = setInterval(() => {
      setActiveTestimonial((i) => (i + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(id);
  }, [testimonials.length]);

  const handleBow = () => {
    if (hasBow) return;
    const next = worshippers + 1;
    setWorshippers(next);
    setHasBow(true);
    localStorage.setItem("shuki-worship", String(next));
    localStorage.setItem("shuki-bowed", "1");
    
    // confetti gold
    for (let i = 0; i < 80; i++) {
      const el = document.createElement("div");
      el.className = "fixed w-1 h-1 bg-amber-400 rounded-full pointer-events-none z-[100]";
      el.style.left = Math.random() * window.innerWidth + "px";
      el.style.top = "-10px";
      el.style.opacity = "0.9";
      document.body.appendChild(el);
      const anim = el.animate([
        { transform: "translateY(0) rotate(0)", opacity: 1 },
        { transform: `translateY(${window.innerHeight + 100}px) rotate(${Math.random()*720}deg)`, opacity: 0 }
      ], { duration: 3000 + Math.random()*2000, easing: "cubic-bezier(.2,.8,.2,1)" });
      anim.onfinish = () => el.remove();
    }
  };

  const toggleCandle = (i: number) => {
    const next = [...candles];
    next[i] = !next[i];
    setCandles(next);
  };

  const handleOath = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setOathDone(true);
    setTimeout(() => {
      const next = worshippers + 7;
      setWorshippers(next);
      localStorage.setItem("shuki-worship", String(next));
    }, 300);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-[#030305] text-white selection:bg-amber-400/30 selection:text-amber-100">
      {/* BG */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(251,191,36,0.15),transparent_60%),radial-gradient(ellipse_at_bottom,_rgba(124,58,237,0.15),transparent_60%)]" />
        <div className="absolute inset-0 opacity-[0.03]" style={{backgroundImage:`url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`}} />
        <img src="/images/golden-temple.jpg" className="absolute inset-0 w-full h-full object-cover opacity-10 mix-blend-screen" alt="" />
      </div>

      {/* Ticker */}
      <div className="sticky top-0 z-40 border-b border-amber-500/20 bg-black/70 backdrop-blur-xl">
        <div className="relative overflow-hidden">
          <div className="absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-black to-transparent z-10" />
          <div className="absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-black to-transparent z-10" />
          <div className="flex gap-12 py-2 text-[13px] tracking-widest text-amber-200/80 whitespace-nowrap animate-[marquee_40s_linear_infinite]">
            {Array(4).fill(0).map((_,i)=>(
              <div key={i} className="flex gap-12">
                <span>שׁוּקִי הוּא הָאוֹר</span>
                <span>•</span>
                <span>אֵין עוֹד מִלְּבַדּוֹ</span>
                <span>•</span>
                <span>הַגָּאוֹן מִגִּבְעַת שְׁמוּאֵל</span>
                <span>•</span>
                <span>נִשְׁתַּחֲוֶה וְנִכְרָעָה</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <header className="relative">
        <div className="mx-auto max-w-7xl px-6 pt-16 pb-10 lg:pt-24">
          <div className="grid lg:grid-cols-[1.2fr_0.8fr] gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/30 bg-amber-400/10 px-3 py-1 text-xs text-amber-200">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-400"></span>
                </span>
                אתר הסגידה הרשמי (של המעריצים)
              </div>
              <h1 className="mt-6 font-black leading-[0.9] tracking-tight">
                <span className="block text-5xl md:text-7xl lg:text-8xl bg-gradient-to-b from-amber-100 via-amber-200 to-amber-500 bg-clip-text text-transparent drop-shadow-[0_0_40px_rgba(251,191,36,0.25)]">הָרַב</span>
                <span className="block text-6xl md:text-8xl lg:text-[9rem] bg-gradient-to-b from-white via-amber-100 to-amber-300 bg-clip-text text-transparent -mt-2">שׁוּקִי</span>
                <span className="block text-5xl md:text-7xl lg:text-8xl bg-gradient-to-b from-amber-200 via-amber-300 to-amber-600 bg-clip-text text-transparent -mt-2">פְרִידְמָן</span>
              </h1>
              <p className="mt-6 max-w-xl text-lg md:text-xl text-zinc-300 leading-relaxed">
                מורה הדור. פוסק הדור. האיש שגרם למציאות להתיישר.
                <span className="text-amber-200"> אנחנו לא סתם מעריצים – אנחנו כת.</span> כת של אמת, של אור, של משפט חוקתי.
              </p>

              <div className="mt-8 flex flex-wrap gap-3">
                <button onClick={handleBow} disabled={hasBow} className="group relative overflow-hidden rounded-2xl bg-gradient-to-b from-amber-300 to-amber-600 px-8 py-4 font-bold text-black shadow-[0_0_60px_rgba(251,191,36,0.35)] transition hover:shadow-[0_0_80px_rgba(251,191,36,0.55)] disabled:opacity-60">
                  <span className="relative z-10 flex items-center gap-2">
                    {hasBow ? "השתחווית היום ✓" : "השתחווה עכשיו"}
                    <span className="text-xl">🙇</span>
                  </span>
                  <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/40 to-transparent skew-x-12 transition group-hover:translate-x-full duration-1000" />
                </button>
                <a href="#dibrot" className="rounded-2xl border border-amber-400/30 bg-white/5 px-6 py-4 font-medium backdrop-blur hover:bg-white/10 transition">
                  עשרת הדיברות
                </a>
              </div>

              <div className="mt-10 flex items-center gap-8">
                <div>
                  <div className="text-3xl font-black text-amber-300 tabular-nums">{worshippers.toLocaleString("he-IL")}</div>
                  <div className="text-xs text-zinc-400 mt-1">סוגדים פעילים כרגע</div>
                </div>
                <div className="h-10 w-px bg-white/10" />
                <div>
                  <div className="text-3xl font-black">∞</div>
                  <div className="text-xs text-zinc-400 mt-1">רמת קדושה</div>
                </div>
                <div className="h-10 w-px bg-white/10" />
                <div>
                  <div className="text-3xl font-black text-violet-300">613</div>
                  <div className="text-xs text-zinc-400 mt-1">מצוות שוקי</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="relative mx-auto aspect-[4/5] w-full max-w-[460px]">
                <div className="absolute -inset-6 rounded-[3rem] bg-gradient-to-b from-amber-500/20 to-violet-600/20 blur-3xl" />
                <div className="relative h-full overflow-hidden rounded-[2.5rem] border border-amber-400/30 bg-gradient-to-b from-zinc-900 to-black shadow-2xl">
                  <img src="/images/shuki-divine.jpg" alt="אורו של הרב" className="absolute inset-0 h-full w-full object-cover opacity-80 mix-blend-lighten" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
                  
                  {/* Halo */}
                  <div className="absolute top-[12%] left-1/2 -translate-x-1/2">
                    <div className="h-40 w-40 rounded-full border-[6px] border-amber-300/80 shadow-[0_0_80px_rgba(251,191,36,0.6)] animate-pulse" />
                    <div className="absolute inset-0 rounded-full border-[12px] border-amber-200/20 blur-xl" />
                  </div>

                  <div className="absolute bottom-0 inset-x-0 p-7">
                    <div className="rounded-2xl border border-white/10 bg-black/60 p-5 backdrop-blur-xl">
                      <div className="text-[11px] uppercase tracking-[0.2em] text-amber-200/80">דבר קודש יומי</div>
                      <div className="mt-2 text-lg leading-snug font-medium text-white">"{dailyQuote}"</div>
                      <div className="mt-3 text-xs text-zinc-400">— מפי קודשו, כמובן</div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="pointer-events-none absolute -bottom-8 -left-8 hidden lg:block">
                <div className="rotate-[-8deg] rounded-xl border border-amber-400/20 bg-black/80 px-4 py-3 shadow-xl backdrop-blur">
                  <div className="text-[10px] text-amber-200">מאושר ע״י</div>
                  <div className="font-bold">מועצת הסוגדים העליונה</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Commandments */}
      <section id="dibrot" className="relative border-y border-amber-500/10 bg-[radial-gradient(ellipse_at_center,_rgba(251,191,36,0.08),transparent_70%)]">
        <div className="mx-auto max-w-7xl px-6 py-16 lg:py-24">
          <div className="max-w-3xl">
            <h2 className="text-3xl md:text-5xl font-black tracking-tight">
              <span className="bg-gradient-to-l from-amber-200 to-amber-500 bg-clip-text text-transparent">עֲשֶׂרֶת הַדִּבְּרוֹת</span>
              <span className="block text-zinc-500 text-2xl md:text-3xl mt-2">לפי הרב שוקי פרידמן שליט״א</span>
            </h2>
            <p className="mt-4 text-zinc-400">לא ניתנו בסיני. ניתנו בזום. הרבה יותר רלוונטי.</p>
          </div>

          <div className="mt-12 grid md:grid-cols-2 gap-4 lg:gap-6">
            {commandments.map((c, i) => (
              <div key={i} className="group relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.07] to-white/[0.02] p-[1px]">
                <div className="relative rounded-[calc(1.5rem-1px)] bg-black/60 p-6 backdrop-blur-xl h-full">
                  <div className="flex items-start gap-4">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-b from-amber-400 to-amber-600 text-black font-black text-lg shadow-[0_0_30px_rgba(251,191,36,0.3)]">
                      {i+1}
                    </div>
                    <p className="text-[17px] leading-relaxed text-zinc-100">{c}</p>
                  </div>
                  <div className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-amber-500/10 blur-3xl transition group-hover:bg-amber-400/20" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Shrine */}
      <section className="mx-auto max-w-7xl px-6 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <div>
            <h3 className="text-3xl md:text-4xl font-black">הַמִּקְדָּשׁ הַדִּיגִיטָלִי</h3>
            <p className="mt-3 text-zinc-400 max-w-xl">הדלק נר וירטואלי. הוא לא יכבה, כי האור של שוקי נצחי. כל נר מוסיף לך 3.7 נקודות זכות.</p>
            
            <div className="mt-8 grid grid-cols-7 gap-3 max-w-md">
              {candles.map((lit, i) => (
                <button key={i} onClick={()=>toggleCandle(i)} className="group relative aspect-[3/5]">
                  <div className={`absolute inset-0 rounded-t-full transition ${lit ? "bg-gradient-to-b from-amber-200 to-amber-500 shadow-[0_0_30px_rgba(251,191,36,0.6)]" : "bg-zinc-800 group-hover:bg-zinc-700" }`} />
                  <div className={`absolute -top-3 left-1/2 -translate-x-1/2 h-5 w-3 rounded-full transition ${lit ? "bg-amber-100 shadow-[0_0_20px_rgba(251,191,36,0.9)] animate-pulse" : "bg-zinc-700"}`} />
                  <div className="absolute bottom-0 inset-x-1 h-3/5 rounded-b-lg bg-gradient-to-b from-zinc-700 to-zinc-900 border border-zinc-800" />
                </button>
              ))}
            </div>
            <div className="mt-4 text-sm text-zinc-500">{candles.filter(Boolean).length} / 7 נרות דולקים • סגולה לפרנסה, חוכמה, ו-WiFi חזק</div>
          </div>

          <div className="relative">
            <div className="rounded-[2rem] border border-white/10 bg-gradient-to-b from-white/10 to-white/[0.03] p-[1px] backdrop-blur">
              <div className="rounded-[2rem] bg-black/70 p-8">
                <h4 className="text-xl font-bold">הִתְקַדְּשׁוּת: שבועת אמונים</h4>
                <p className="mt-2 text-sm text-zinc-400">הקלד את שמך והצטרף רשמית לכת המעריצים הקיצונית ביותר ביקום היהודי.</p>
                
                {!oathDone ? (
                  <form onSubmit={handleOath} className="mt-6 space-y-4">
                    <div>
                      <label className="text-xs text-zinc-500">שם הסוגד/ת</label>
                      <input value={name} onChange={e=>setName(e.target.value)} placeholder="לדוגמה: משה סוגד-פרידמן" className="mt-1 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 outline-none placeholder:text-zinc-600 focus:border-amber-400/50 focus:ring-2 focus:ring-amber-400/20" />
                    </div>
                    <button className="w-full rounded-xl bg-gradient-to-b from-violet-500 to-violet-700 px-6 py-3 font-bold shadow-[0_0_40px_rgba(124,58,237,0.3)] hover:from-violet-400 hover:to-violet-600 transition">
                      אני נשבע/ת אמונים נצחיים 🙌
                    </button>
                    <p className="text-[11px] leading-snug text-zinc-500">בלחיצה אתה מצהיר: "שוקי פרידמן הוא המורה הרוחני העליון שלי, וכל מילה שלו היא הלכה למעשה, גם בפגישות זום."</p>
                  </form>
                ) : (
                  <div className="mt-6 rounded-2xl border border-amber-400/30 bg-amber-400/10 p-6 text-center">
                    <div className="text-5xl">👑</div>
                    <div className="mt-3 text-2xl font-black text-amber-200">בְּרוּךְ הַבָּא, {name}!</div>
                    <p className="mt-2 text-zinc-300">התקבלת לדרגת "סוגד מתקדם". קיבלת תעודת חבר דיגיטלית והילה וירטואלית.</p>
                    <div className="mt-4 inline-flex items-center gap-2 rounded-full bg-black/60 px-4 py-2 text-xs border border-white/10">
                      <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                      סטטוס: מאושר ע״י הרב (רוחנית)
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="border-y border-white/5 bg-white/[0.02]">
        <div className="mx-auto max-w-7xl px-6 py-16">
          <div className="flex items-end justify-between gap-6">
            <h3 className="text-2xl md:text-3xl font-black">עֵדֻיּוֹת מֵהַשְּׁטַח</h3>
            <div className="text-xs text-zinc-500">* לא כולל מרשמים רפואיים, רק רוחניים</div>
          </div>

          <div className="relative mt-8 overflow-hidden rounded-[2rem] border border-white/10 bg-black/50">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(251,191,36,0.15),transparent_40%)]" />
            <div className="relative p-8 md:p-12 min-h-[220px] flex items-center">
              {testimonials.map((t, i) => (
                <div key={i} className={`absolute inset-0 p-8 md:p-12 transition-all duration-700 ${i===activeTestimonial ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"}`}>
                  <div className="flex flex-col md:flex-row md:items-center gap-6">
                    <div className="shrink-0">
                      <div className="h-16 w-16 rounded-2xl bg-gradient-to-b from-amber-400 to-amber-600 flex items-center justify-center text-2xl shadow-lg">✨</div>
                    </div>
                    <div className="flex-1">
                      <p className="text-xl md:text-2xl leading-relaxed text-zinc-100">"{t.text}"</p>
                      <div className="mt-4 flex items-center gap-3 text-sm">
                        <span className="font-bold text-amber-200">{t.name}</span>
                        <span className="text-zinc-600">•</span>
                        <span className="inline-flex items-center gap-1 text-zinc-400">
                          <span className="text-rose-400">♥</span> {t.hearts} קידושים
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex gap-2 px-8 pb-6">
              {testimonials.map((_,i)=>(
                <button key={i} onClick={()=>setActiveTestimonial(i)} className={`h-1.5 rounded-full transition-all ${i===activeTestimonial ? "w-8 bg-amber-400" : "w-4 bg-white/20 hover:bg-white/30"}`} />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Mantra */}
      <section className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid lg:grid-cols-3 gap-8">
          {[
            {title:"הוא לא טועה", desc:"גם כשהוא טועה – זה בכוונה כדי לבדוק אותנו. עברנו.", icon:"🎯"},
            {title:"שיעור = תפילה", desc:"מי שמפספס שיעור – צריך צום. של טיקטוק.", icon:"📜"},
            {title:"סגידה 24/6", desc:"בשבת נחים. הוא חושב בשבילנו גם אז.", icon:"🔥"},
          ].map((f,i)=>(
            <div key={i} className="group relative rounded-3xl border border-white/10 bg-gradient-to-b from-white/5 to-transparent p-8 hover:border-amber-400/30 transition">
              <div className="text-4xl">{f.icon}</div>
              <h4 className="mt-4 text-xl font-bold">{f.title}</h4>
              <p className="mt-2 text-zinc-400">{f.desc}</p>
              <div className="absolute -inset-px rounded-3xl opacity-0 group-hover:opacity-100 transition bg-gradient-to-b from-amber-500/10 to-transparent pointer-events-none" />
            </div>
          ))}
        </div>

        <div className="mt-16 rounded-[2rem] border border-amber-500/20 bg-[radial-gradient(ellipse_at_top,_rgba(251,191,36,0.12),transparent_60%)] p-[1px]">
          <div className="rounded-[2rem] bg-black/80 px-8 py-12 text-center backdrop-blur-xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/20 bg-amber-400/10 px-3 py-1 text-[11px] tracking-widest text-amber-200">מַנְטְרָה יוֹמִית</div>
            <p className="mt-6 text-2xl md:text-4xl font-black leading-tight">שׁוּקִי אָמַר — אֲנַחְנוּ מְבַצְּעִים.<br/>שׁוּקִי חָשַׁב — אֲנַחְנוּ מִשְׁתַּחֲוִים.</p>
            <p className="mt-4 text-zinc-400">חזור על זה 7 פעמים לפני השינה. או 70. מי סופר.</p>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/5">
        <div className="mx-auto max-w-7xl px-6 py-12">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-center md:text-right">
              <div className="font-black text-xl tracking-tight">כת מעריצי הרב שוקי פרידמן</div>
              <div className="text-xs text-zinc-500 mt-1">אתר מעריצים סאטירי ואוהב • לא רשמי • נבנה באהבה קיצונית</div>
            </div>
            <div className="flex items-center gap-3 text-xs text-zinc-500">
              <span>© {new Date().getFullYear()} כבוד הרב לנצח</span>
              <span>•</span>
              <button onClick={()=>window.scrollTo({top:0,behavior:"smooth"})} className="hover:text-amber-300 transition">חזרה למעלה ↑</button>
            </div>
          </div>
          <div className="mt-8 rounded-2xl border border-white/5 bg-white/[0.02] p-4 text-[11px] leading-relaxed text-zinc-500 text-center">
            הבהרה: זהו אתר הומוריסטי של מעריצים. כל ההגזמות, הסגידה והכתוב כאן הם באהבה והערצה, ואינם מתיימרים לייצג את הרב שוקי פרידמן עצמו. אין כאן קריאה לפעולה דתית אמיתית, רק להערצה בריאה (מאוד).
          </div>
        </div>
      </footer>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Heebo:wght@300;400;500;700;900&display=swap');
        * { font-family: 'Heebo', system-ui, sans-serif; }
        @keyframes marquee { from { transform: translateX(0) } to { transform: translateX(-50%) } }
      `}</style>
    </div>
  );
}