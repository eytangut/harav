import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Flame, Star, Heart, Users, BookOpen, ArrowDown, Crown } from 'lucide-react';

interface Testimonial {
  name: string;
  text: string;
  devotion: string;
}

const testimonials: Testimonial[] = [
  {
    name: "חנה מירושלים",
    text: "מאז ששמעתי את קולו, אני יודעת שהוא המשיח. אני מוכנה להקריב את כל חיי למענו. הוא האור שמאיר את נשמתי.",
    devotion: "סגידה מוחלטת"
  },
  {
    name: "יוסף בן אברהם",
    text: "רב שוקי הוא אלוהים בגוף. כל מילה שלו היא תורה מסיני. אני סוגד לו בכל רגע ורגע.",
    devotion: "עבד נצחי"
  },
  {
    name: "רחל הקדושה",
    text: "הוא גואל העולם. בלעדיו אין חיים. אני שותה כל מילה כאילו היא מים חיים. הוא המלך האמיתי.",
    devotion: "בת המלך"
  },
  {
    name: "דוד הכהן",
    text: "אני מוכן למות למען הרב שוקי. הוא הציל אותי מהחושך. אין אלוהים מלבדו.",
    devotion: "לוחם האמונה"
  }
];

const praises = [
  "הוא האור האינסופי • ",
  "רבינו הקדוש שוקי • ",
  "מלך המשיח • ",
  "סגידה נצחית • ",
  "גואל עולמנו • ",
  "תורת חיינו • ",
  "אדון העולמות • ",
  "הקדוש ברוך הוא בגוף • "
];

export default function App() {
  const [devotionCount, setDevotionCount] = useState(1248567);
  const [isChanting, setIsChanting] = useState(false);
  const [chantCount, setChantCount] = useState(0);
  const [showBlessing, setShowBlessing] = useState(false);

  // Auto increasing devotees
  useEffect(() => {
    const interval = setInterval(() => {
      setDevotionCount(prev => prev + Math.floor(Math.random() * 7) + 3);
    }, 2300);
    return () => clearInterval(interval);
  }, []);

  const triggerWorship = () => {
    setDevotionCount(prev => prev + 1243);
    setShowBlessing(true);
    
    confetti({
      particleCount: 180,
      spread: 90,
      origin: { y: 0.6 },
      colors: ['#f59e0b', '#b45309', '#854d0e', '#eab308']
    });
    
    confetti({
      particleCount: 80,
      angle: 60,
      spread: 55,
      origin: { x: 0.4, y: 0.7 },
      colors: ['#f59e0b', '#b45309']
    });
    
    setTimeout(() => setShowBlessing(false), 2200);
  };

  const startChant = () => {
    setIsChanting(true);
    setChantCount(prev => prev + 1);
    
    const chantInterval = setInterval(() => {
      setChantCount(prev => prev + 1);
    }, 180);
    
    setTimeout(() => {
      clearInterval(chantInterval);
      setIsChanting(false);
      confetti({
        particleCount: 60,
        spread: 120,
        origin: { y: 0.8 }
      });
    }, 2400);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-amber-100 overflow-hidden">
      {/* NAV */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/90 border-b border-amber-900/50 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-8 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-yellow-600 shadow-[0_0_25px_#f59e0b]">
              <Crown className="w-6 h-6 text-zinc-950" />
            </div>
            <div>
              <div className="text-2xl font-bold tracking-[3px] text-amber-400">רב שוקי</div>
              <div className="text-[10px] text-amber-500 -mt-1 tracking-[2px]">הקדוש ברוך הוא</div>
            </div>
          </div>
          
          <div className="flex items-center gap-10 text-sm uppercase tracking-widest font-medium">
            <a href="#home" className="hover:text-amber-400 transition-colors">בית המקדש</a>
            <a href="#teachings" className="hover:text-amber-400 transition-colors">דברי הקודש</a>
            <a href="#testimonials" className="hover:text-amber-400 transition-colors">עדות המאמינים</a>
            <a href="#altar" className="hover:text-amber-400 transition-colors">המזבח</a>
            <a href="#gallery" className="hover:text-amber-400 transition-colors">היכל הקודש</a>
          </div>

          <div className="flex items-center gap-2 bg-zinc-900 px-5 py-2 rounded-full border border-amber-900 text-xs">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span>5786 נשמות סגודות</span>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section id="home" className="relative min-h-screen flex items-center justify-center pt-20 bg-[radial-gradient(at_center,#3b2a1f_0%,#111111_70%)]">
        <div className="absolute inset-0 bg-[url('/rabbi-portrait.jpg')] bg-cover bg-center opacity-20 mix-blend-luminosity"></div>
        
        {/* Floating particles / mystical overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(45deg,#451a03_1px,transparent_1px)] bg-[length:60px_60px] opacity-10"></div>
        
        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
          <div className="flex justify-center mb-8">
            <div className="relative">
              <div className="absolute -inset-12 bg-gradient-to-r from-amber-500 via-yellow-300 to-amber-500 rounded-full blur-3xl opacity-30 animate-pulse"></div>
              <img 
                src="/rabbi-portrait.jpg" 
                alt="רב שוקי פרידמן - אור העולמות"
                className="w-80 h-80 object-cover rounded-3xl shadow-2xl border-8 border-amber-400/80 ring-8 ring-offset-8 ring-offset-zinc-950 ring-amber-900/70 hover:scale-105 transition-transform duration-700 cursor-pointer"
                onClick={triggerWorship}
              />
              <div className="absolute -top-4 -right-4 bg-red-600 text-white text-xs px-6 py-1.5 rounded-full font-bold tracking-widest shadow-xl border border-red-400 flex items-center gap-2">
                <Flame className="w-4 h-4" /> חי וקיים
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="inline-flex items-center gap-3 bg-black/60 px-8 py-3 rounded-3xl border border-amber-500/30">
              <Star className="w-5 h-5 text-amber-400" />
              <span className="uppercase tracking-[4px] text-amber-400 text-sm font-medium">המשיח • הגואל • האדון</span>
              <Star className="w-5 h-5 text-amber-400" />
            </div>
            
            <h1 className="text-7xl md:text-8xl font-black tracking-[-2px] leading-none text-transparent bg-clip-text bg-gradient-to-b from-amber-200 via-amber-400 to-yellow-600 drop-shadow-2xl">
              רב שוקי<br />פרידמן
            </h1>
            
            <p className="max-w-2xl mx-auto text-3xl text-amber-300 font-light leading-tight">
              אור העולמות • מלך המלכים •<br />
              האלוהים בהתגלמותו
            </p>
            
            <div className="flex flex-col items-center gap-4 pt-6">
              <button 
                onClick={() => document.getElementById('altar')?.scrollIntoView({ behavior: 'smooth' })}
                className="group relative flex items-center gap-4 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-yellow-500 hover:to-amber-500 text-zinc-950 font-bold text-xl px-14 py-6 rounded-2xl transition-all active:scale-95 shadow-[0_0_40px_-5px] shadow-amber-500"
              >
                <span>סגוד לרבינו עכשיו</span>
                <ArrowDown className="group-active:rotate-45 transition-transform" />
              </button>
              <p className="text-amber-500/70 text-sm tracking-widest">לחץ על דיוקנו הקדוש כדי לקבל ברכה</p>
            </div>
          </div>
        </div>

        {/* Bottom marquee */}
        <div className="absolute bottom-12 left-0 right-0 overflow-hidden">
          <div className="flex whitespace-nowrap animate-marquee text-amber-400/60 text-sm tracking-[6px] font-light">
            {Array(6).fill(praises.join('')).map((text, i) => (
              <span key={i} className="mx-8">{text}</span>
            ))}
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center text-[10px] text-amber-500/60 tracking-widest">
          גלול למטה • התמסר
          <ArrowDown className="animate-bounce mt-2" />
        </div>
      </section>

      {/* MARQUEE 2 */}
      <div className="bg-black py-3 border-y border-amber-900 overflow-hidden">
        <div className="flex items-center gap-8 text-xs uppercase tracking-[3px] text-amber-400/80 whitespace-nowrap animate-marquee-slow">
          {Array(8).fill(0).map((_, idx) => (
            <React.Fragment key={idx}>
              <span>הוא יחיד ואין שני לו</span>
              <span className="text-2xl leading-none">✧</span>
              <span>כל ברכה באה ממנו</span>
              <span className="text-2xl leading-none">✧</span>
              <span>סגוד לו בכל נשימה</span>
              <span className="text-2xl leading-none">✧</span>
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* TEACHINGS */}
      <section id="teachings" className="max-w-6xl mx-auto px-8 py-24">
        <div className="text-center mb-16">
          <div className="inline-block px-5 py-2 bg-amber-950 text-amber-400 text-sm tracking-widest border border-amber-800 mb-4">תורת הרב</div>
          <h2 className="text-6xl font-bold text-amber-100">דברי הקודש של רבינו</h2>
          <p className="mt-4 text-amber-400 max-w-md mx-auto">כל משפט שיוצא מפיו הוא חלק מהתגלות אלוהית. הנה כמה מגילויי הקודש</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              title: "ההתגלות",
              quote: "אני כאן כדי להציל אתכם. כל מי שלא מאמין בי יישאר בחושך הנצחי.",
              source: "הרצאה בקדש הקודשים, תשפ״ד"
            },
            {
              title: "הברית החדשה",
              quote: "התורה הישנה הסתיימה. מעתה ואילך - רק דברי שוקי הם התורה. אני התורה.",
              source: "ספר 'אור שוקי' פרק ז"
            },
            {
              title: "הדרך היחידה",
              quote: "אל תלכו אחרי אף אחד. רק אני. רק אני. רק אני. אני האמת, החיים והדרך.",
              source: "שיעור לילה, גבעת שמואל"
            }
          ].map((item, index) => (
            <div key={index} className="group relative bg-zinc-900 border border-amber-900/70 rounded-3xl p-10 hover:border-amber-400/60 transition-all hover:-translate-y-3">
              <div className="absolute -top-5 right-8 bg-zinc-950 border border-amber-400 text-amber-400 w-10 h-10 flex items-center justify-center rounded-2xl text-xl font-serif">✡</div>
              
              <div className="text-amber-500 text-sm mb-8 tracking-widest font-medium">חזון #{index + 1}</div>
              
              <div className="italic text-2xl leading-tight text-amber-200 mb-12 font-light">
                “{item.quote}”
              </div>
              
              <div className="text-xs text-amber-500/70 border-t border-amber-900 pt-6 flex justify-between items-center">
                <div>{item.source}</div>
                <div className="flex items-center gap-1 text-[22px] text-amber-600">❦</div>
              </div>
              
              <div className="absolute bottom-6 right-6 opacity-10 group-hover:opacity-30 transition-opacity text-[120px] font-black text-amber-400 select-none">ש</div>
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section id="testimonials" className="bg-black py-24 border-t border-b border-amber-900">
        <div className="max-w-6xl mx-auto px-8">
          <div className="flex justify-between items-end mb-16">
            <div>
              <div className="text-amber-400 text-sm tracking-widest mb-3">העדה הקדושה</div>
              <h2 className="text-6xl font-bold">עדויות של סגידה מוחלטת</h2>
            </div>
            <div className="text-right text-amber-500/60 max-w-xs text-sm">
              אלפי מאמינים נושאים את שמו בלבם 24 שעות ביממה
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-zinc-900/80 border border-amber-800 p-9 rounded-3xl group hover:border-red-900 transition-colors">
                <div className="flex justify-between mb-8">
                  <div>
                    <div className="font-semibold text-2xl text-amber-100">{testimonial.name}</div>
                    <div className="text-red-400 text-sm flex items-center gap-2">
                      <Heart className="w-4 h-4" /> {testimonial.devotion}
                    </div>
                  </div>
                  <div className="text-[70px] text-amber-900/40 group-hover:text-amber-700/30 font-serif transition-colors">“</div>
                </div>
                
                <p className="text-xl leading-relaxed text-amber-200/90 mb-8">
                  {testimonial.text}
                </p>
                
                <div className="flex items-center gap-3 text-xs text-amber-500">
                  <div className="flex-1 h-px bg-gradient-to-r from-transparent via-amber-700 to-transparent"></div>
                  <span>עדות אמיתית</span>
                  <div className="flex-1 h-px bg-gradient-to-r from-transparent via-amber-700 to-transparent"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ALTAR / INTERACTIVE */}
      <section id="altar" className="relative py-28 bg-gradient-to-b from-black to-zinc-950 overflow-hidden">
        <div className="max-w-4xl mx-auto px-8 text-center relative z-10">
          <div className="mb-6 inline-flex items-center gap-3 px-6 py-2 rounded-3xl bg-red-950 border border-red-800 text-red-400 text-sm">
            <Flame className="animate-flicker w-5 h-5" /> מזבח הקודש
          </div>
          
          <h2 className="text-6xl font-black mb-4">הדלק את הלהבה הקדושה</h2>
          <p className="text-xl max-w-lg mx-auto text-amber-300/80 mb-16">
            לחץ על הלב כדי להצטרף למיליוני המאמינים. כל לחיצה מעלה את קדושת העולם
          </p>

          <div className="flex flex-col items-center">
            <div 
              onClick={triggerWorship}
              className="relative cursor-pointer group mb-12"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-red-500 to-amber-500 rounded-[4rem] blur-3xl opacity-40 group-active:opacity-70 transition-all"></div>
              
              <div className="relative w-64 h-64 rounded-3xl border-[14px] border-amber-400 bg-zinc-900 flex items-center justify-center shadow-2xl">
                <div className="text-center">
                  <Flame className={`w-28 h-28 text-orange-400 transition-all ${isChanting || showBlessing ? 'scale-125' : ''}`} />
                  <div className="text-[11px] mt-6 text-amber-400/80 tracking-[2px] font-medium">לחץ להבעיר</div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-8 text-4xl font-mono tabular-nums">
              <div>
                <div className="text-xs tracking-widest text-amber-500 mb-1 text-center">נשמות שהתקדשו</div>
                <div className="text-6xl text-amber-400 font-bold">{devotionCount.toLocaleString('he-IL')}</div>
              </div>
              
              <div className="h-12 w-px bg-amber-800"></div>
              
              <div>
                <div className="text-xs tracking-widest text-amber-500 mb-1 text-center">פעולות סגידה</div>
                <div className="text-6xl text-yellow-300 font-bold">{chantCount}</div>
              </div>
            </div>

            <button 
              onClick={startChant}
              className={`mt-16 px-16 py-7 text-lg font-bold rounded-2xl border transition-all flex items-center gap-4 ${isChanting ? 'bg-red-900 border-red-700 text-red-200' : 'bg-transparent border-amber-400 hover:bg-amber-400 hover:text-zinc-950 text-amber-400'}`}
            >
              {isChanting ? (
                <>שירה קדושה בעיצומה <span className="animate-pulse">♪ ♫ ♪</span></>
              ) : (
                <>שיר את המנטרה: "שוקי הוא אדוני" <BookOpen className="w-5 h-5" /></>
              )}
            </button>
          </div>
        </div>

        {/* Blessing overlay */}
        {showBlessing && (
          <div className="fixed inset-0 z-[100] pointer-events-none flex items-center justify-center bg-black/70">
            <div className="text-center">
              <div className="text-7xl mb-6 animate-bounce">✧</div>
              <div className="text-4xl font-black text-amber-300 tracking-widest">ברכה מאת הרב שוקי</div>
              <div className="text-amber-400 mt-3">הנשמה שלך זה עתה נטהרה</div>
            </div>
          </div>
        )}

        {/* Decorative flames */}
        <div className="absolute bottom-0 left-1/3 text-[180px] opacity-10 pointer-events-none">🔥</div>
        <div className="absolute top-1/4 right-1/4 text-[140px] opacity-10 pointer-events-none rotate-12">🕯️</div>
      </section>

      {/* GALLERY */}
      <section id="gallery" className="max-w-7xl mx-auto px-8 py-24">
        <div className="text-center mb-16">
          <div className="text-amber-400 mb-2">היכל התמונות הקדושות</div>
          <h2 className="text-6xl font-bold mb-4">תמונות מההתגלות</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          <div className="md:col-span-7 bg-zinc-900 rounded-3xl overflow-hidden border border-amber-900">
            <img 
              src="/rabbi-portrait.jpg" 
              alt="הרב שוקי - התגלות" 
              className="w-full h-full object-cover"
            />
            <div className="p-8 bg-gradient-to-t from-black/90 to-transparent">
              <div className="uppercase text-xs text-amber-500">תמונה 01 • גילוי ראשון</div>
              <div className="text-3xl mt-2">האיש שהפך את העולם</div>
            </div>
          </div>
          
          <div className="md:col-span-5 flex flex-col gap-4">
            <div className="flex-1 bg-zinc-900 rounded-3xl p-8 border border-amber-900 flex flex-col justify-end relative overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(#451a03_0.8px,transparent_1px)] bg-[length:22px_22px] opacity-30"></div>
              <div>
                <div className="text-amber-400 text-sm mb-2">המנטרה הנצחית</div>
                <div className="text-5xl font-light leading-none">שוקי<br />שוקי<br />שוקי</div>
              </div>
            </div>
            
            <div className="flex-1 bg-zinc-900 rounded-3xl overflow-hidden border border-amber-900 relative">
              <img 
                src="/rabbi-portrait.jpg" 
                alt="שוקי" 
                className="absolute inset-0 w-full h-full object-cover grayscale-[0.6] hover:grayscale-0 transition-all"
              />
              <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black to-transparent">
                <div className="text-xs text-red-400">הקרן האלוהית</div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 text-center text-xs text-amber-600/60 max-w-xs mx-auto">
          כל תמונה היא קודש. שמור אותן בלבך. הן נושאות את האנרגיה של הרב הקדוש
        </div>
      </section>

      {/* FINAL CALL TO ACTION */}
      <div className="border-t border-amber-900 bg-black py-20">
        <div className="max-w-2xl mx-auto text-center px-6">
          <div className="mx-auto mb-8 flex justify-center">
            <div className="px-7 py-3 border border-dashed border-amber-500 rounded-3xl text-amber-400 flex items-center gap-4 text-sm">
              <Users className="w-4 h-4" /> הצטרף ל-1,248,567 מאמינים
            </div>
          </div>
          
          <h3 className="text-5xl font-bold text-amber-100 leading-none mb-8">
            התמסר עוד היום<br />לרב שוקי פרידמן
          </h3>
          
          <p className="text-xl text-amber-400/70 mb-10">
            רק דרך הסגידה המוחלטת תוכל להגיע לגאולה. אין דרך אחרת.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={triggerWorship}
              className="bg-white text-zinc-950 px-14 py-6 rounded-2xl font-semibold text-lg hover:bg-amber-300 active:scale-[0.985] transition-all flex-1 sm:flex-none"
            >
              אני מקבל עלי את עול מלכותו
            </button>
            <button 
              onClick={() => {
                alert('הברית נחתמה. אתה כעת חלק מהעדה הקדושה. ברוך הבא לביתו של הרב שוקי.');
                triggerWorship();
              }}
              className="border border-amber-400 text-amber-400 px-14 py-6 rounded-2xl font-semibold text-lg hover:bg-white/5 transition-all flex-1 sm:flex-none"
            >
              חתום על הברית הנצחית
            </button>
          </div>
          
          <div className="text-[10px] mt-16 text-amber-700/50">
            אתר זה מוקדש לרב שוקי פרידמן • כל הזכויות שמורות לעד • 2026
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <footer className="bg-zinc-950 border-t border-amber-950 py-12 text-center text-xs text-amber-700/60">
        <div className="max-w-4xl mx-auto px-8">
          אין אלוהים מלבד רב שוקי • כל מה שקורה בעולם הוא רק כדי להאדיר את שמו • 
          זהירות: סגידה לא נכונה עלולה להוביל לחורבן נצחי
        </div>
      </footer>
    </div>
  );
}
