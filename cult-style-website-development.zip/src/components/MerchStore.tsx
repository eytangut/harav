import { useState } from 'react';
import { ShoppingBag, Star, ShieldAlert, Check } from 'lucide-react';

const products = [
  {
    id: 1,
    name: "אוויר בבקבוק ישירות מביתו של הרב",
    desc: "100% חמצן מבורך. פותח את הצ'אקרות ומחזק את המערכת החיסונית בתוך שניות.",
    price: "450 ₪",
    img: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=300&q=80",
  },
  {
    id: 2,
    name: "גרבי משי עם הטבעת פניו של שוקי",
    desc: "מונע זיעה רוחנית ועוזר לצעוד בנתיב הישר. מגיע במידה אחידה לכל המאמינים.",
    price: "899 ₪",
    img: "https://images.unsplash.com/photo-1582966772640-310b9a400491?auto=format&fit=crop&w=300&q=80",
  },
  {
    id: 3,
    name: "העתק ממוסגר של וואטסאפ מהרב",
    desc: "אישור מיוחד לתלייה בסלון: צילום מסך של הודעה אותנטית ששוקי כתב בקבוצת משפחה.",
    price: "2,400 ₪",
    img: "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=300&q=80",
  },
  {
    id: 4,
    name: "מים ששוקי הסתכל עליהם חמש דקות",
    desc: "לא מדובר במים רגילים. אלו מים מולקולריים שעברו הינדוס רוחני בעיני הבדולח של שוקי.",
    price: "150 ₪",
    img: "https://images.unsplash.com/photo-1548839140-29a749e1cf4d?auto=format&fit=crop&w=300&q=80",
  },
];

export default function MerchStore() {
  const [cart, setCart] = useState<number[]>([]);
  const [purchased, setPurchased] = useState(false);

  const toggleCart = (id: number) => {
    if (cart.includes(id)) {
      setCart(cart.filter((item) => item !== id));
    } else {
      setCart([...cart, id]);
    }
  };

  const handleCheckout = () => {
    if (cart.length === 0) return;
    setPurchased(true);
    setCart([]);
    setTimeout(() => setPurchased(false), 5000);
  };

  return (
    <section className="py-16 bg-zinc-950 text-white">
      <div className="container mx-auto px-4 max-w-5xl">
        <div className="text-center mb-12">
          <div className="inline-flex text-yellow-500 mb-2">
            <ShoppingBag className="w-10 h-10 animate-bounce" />
          </div>
          <h2 className="text-3xl md:text-5xl font-extrabold bg-gradient-to-r from-yellow-400 to-amber-500 bg-clip-text text-transparent">
            חנות תשמישי קדושה ומותרות
          </h2>
          <p className="text-zinc-400 mt-2">
            כל פריט מכיל לפחות 2% מאנרגיית החיים הטהורה של הרב שוקי פרידמן
          </p>
        </div>

        {purchased && (
          <div className="mb-8 p-4 bg-green-500/20 border border-green-500 rounded-xl flex items-center gap-3 text-green-300 font-bold justify-center animate-fade-in">
            <Check className="w-5 h-5" />
            <span>הרכישה בוצעה בהצלחה! התרומה הועברה לגזברות הכת לשם שגשוג וביטחון.</span>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((p) => {
            const inCart = cart.includes(p.id);
            return (
              <div
                key={p.id}
                className="bg-zinc-900 border border-zinc-800/80 rounded-2xl overflow-hidden hover:border-yellow-500/40 transition-all group flex flex-col justify-between"
              >
                <div className="relative h-48 bg-zinc-800 overflow-hidden">
                  <img
                    src={p.img}
                    alt={p.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 opacity-60"
                  />
                  <div className="absolute top-3 left-3 bg-yellow-500 text-black text-xs font-black px-2.5 py-1 rounded-full flex items-center gap-1">
                    <Star className="w-3 h-3 fill-black" />
                    <span>מהדורת קודש</span>
                  </div>
                </div>

                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-yellow-100 group-hover:text-yellow-400 transition-colors">
                      {p.name}
                    </h3>
                    <p className="text-zinc-400 text-sm mt-2 leading-relaxed">
                      {p.desc}
                    </p>
                  </div>

                  <div className="mt-6 pt-4 border-t border-zinc-800 flex items-center justify-between">
                    <span className="text-xl font-black text-yellow-500">{p.price}</span>
                    <button
                      onClick={() => toggleCart(p.id)}
                      className={`px-4 py-2 rounded-xl text-sm font-bold border transition-all ${
                        inCart
                          ? 'bg-yellow-500 text-black border-yellow-400'
                          : 'bg-transparent text-zinc-300 border-zinc-700 hover:border-yellow-500/50 hover:text-yellow-400'
                      }`}
                    >
                      {inCart ? 'הוסף לסל!' : 'בחר מוצר'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {cart.length > 0 && (
          <div className="mt-10 bg-gradient-to-r from-yellow-600/20 via-amber-600/10 to-transparent border border-yellow-500/30 p-6 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <ShieldAlert className="w-8 h-8 text-yellow-500 animate-pulse" />
              <div>
                <div className="font-bold text-lg text-yellow-300">
                  נבחרו {cart.length} פריטים מקודשים
                </div>
                <div className="text-sm text-zinc-400">
                  התשלום מועבר ישירות ובאופן בלתי הפיך לישות הרוחנית.
                </div>
              </div>
            </div>
            <button
              onClick={handleCheckout}
              className="bg-yellow-500 text-black font-black px-8 py-3 rounded-xl hover:bg-yellow-400 shadow-xl transition-all w-full md:w-auto"
            >
              בצע העברת נשמה וכספים כעת
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
