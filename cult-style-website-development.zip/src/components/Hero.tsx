import { useState, useEffect } from 'react';
import { Eye, Flame, Award, Globe, ArrowLeft } from 'lucide-react';

interface HeroProps {
  setActiveTab: (tab: string) => void;
}

export default function Hero({ setActiveTab }: HeroProps) {
  const [timeLeft, setTimeLeft] = useState({
    hours: 14,
    minutes: 32,
    seconds: 45,
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { hours: prev.hours, minutes: prev.minutes - 1, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return { hours: 24, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative min-h-[90vh] flex flex-col items-center justify-center text-white overflow-hidden bg-black">
      {/* Background Lights */}
      <div className="absolute inset-0 z-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-yellow-900/40 via-black to-black" />
      <div className="absolute top-[-10%] left-[-10%] w-[400px] h-[400px] rounded-full bg-yellow-600/10 blur-[120px] animate-pulse" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[400px] h-[400px] rounded-full bg-red-600/10 blur-[120px] animate-pulse delay-700" />

      {/* Main Content */}
      <div className="container mx-auto px-4 relative z-10 flex flex-col md:flex-row items-center justify-between gap-12 max-w-6xl py-12">
        <div className="flex-1 text-right space-y-6 order-2 md:order-1">
          <div className="inline-flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/40 px-4 py-1 rounded-full text-yellow-400 font-bold text-sm tracking-widest animate-bounce">
            <Flame className="w-4 h-4 fill-yellow-500" />
            מנהיג הדור והעולמות המקבילים
          </div>

          <h1 className="text-4xl md:text-7xl font-black tracking-tight leading-none bg-gradient-to-r from-white via-yellow-200 to-amber-500 bg-clip-text text-transparent drop-shadow-[0_4px_30px_rgba(245,158,11,0.3)]">
            הרב שוקי פרידמן <br />
            <span className="text-2xl md:text-4xl font-extrabold text-yellow-400 block mt-2">
              שליט"א (שיחיה לאורך ימים טריליון אמן)
            </span>
          </h1>

          <p className="text-zinc-300 text-lg md:text-xl font-medium leading-relaxed max-w-2xl">
            היחיד שרואה את העתיד, מנשק את העבר ויושב בנוחות מוחלטת בהווה. דבריו מפיחים חיים בדומם ומסירים חלודה מהנשמה. הצטרפו לכת והפכו למאמינים מורשים.
          </p>

          <div className="flex flex-wrap gap-4 pt-4">
            <button
              onClick={() => setActiveTab('quiz')}
              className="flex items-center gap-2 bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-400 hover:to-amber-500 text-black font-black text-lg px-8 py-4 rounded-2xl shadow-[0_10px_30px_rgba(245,158,11,0.4)] hover:shadow-[0_15px_40px_rgba(245,158,11,0.6)] transform hover:-translate-y-1 transition-all duration-300"
            >
              <span>להגשת בקשת הצטרפות</span>
              <ArrowLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => setActiveTab('shrine')}
              className="flex items-center gap-2 bg-zinc-900 border border-zinc-700 hover:border-yellow-500 text-white font-bold px-8 py-4 rounded-2xl transition-all duration-300"
            >
              <Eye className="w-5 h-5 text-yellow-500 animate-pulse" />
              <span>כניסה להיכל האנרגטי</span>
            </button>
          </div>

          {/* Stats/Badges */}
          <div className="grid grid-cols-3 gap-4 pt-8">
            <div className="bg-zinc-900/50 border border-zinc-800 p-4 rounded-xl text-center hover:border-yellow-500/30 transition-all">
              <Award className="w-6 h-6 text-yellow-500 mx-auto mb-1" />
              <div className="text-2xl font-black">9.8M</div>
              <div className="text-xs text-zinc-400 font-bold">חסידים נאורים</div>
            </div>
            <div className="bg-zinc-900/50 border border-zinc-800 p-4 rounded-xl text-center hover:border-yellow-500/30 transition-all">
              <Globe className="w-6 h-6 text-amber-500 mx-auto mb-1" />
              <div className="text-2xl font-black">100%</div>
              <div className="text-xs text-zinc-400 font-bold">דיוק בנבואות</div>
            </div>
            <div className="bg-zinc-900/50 border border-zinc-800 p-4 rounded-xl text-center hover:border-yellow-500/30 transition-all">
              <Flame className="w-6 h-6 text-red-500 mx-auto mb-1" />
              <div className="text-2xl font-black">0</div>
              <div className="text-xs text-zinc-400 font-bold">ספקות</div>
            </div>
          </div>
        </div>

        {/* Image / Portrait */}
        <div className="flex-1 flex justify-center order-1 md:order-2 relative group">
          <div className="absolute inset-0 bg-gradient-to-t from-yellow-500/30 to-red-500/20 rounded-full blur-[80px] opacity-70 group-hover:opacity-100 transition-opacity duration-1000" />
          <div className="relative w-72 h-72 md:w-96 md:h-96 rounded-full border-4 border-yellow-500 p-2 bg-zinc-900 shadow-[0_0_50px_rgba(234,179,8,0.3)] hover:shadow-[0_0_80px_rgba(234,179,8,0.5)] transform hover:scale-105 transition-all duration-700">
            <img
              src="/shuki_saint.jpg"
              alt="הוד קדושתו הרב שוקי פרידמן"
              className="w-full h-full object-cover rounded-full filter brightness-110 contrast-110"
              onError={(e) => {
                // Fallback inside case image is slow to load
                (e.target as HTMLImageElement).src =
                  'https://images.unsplash.com/photo-1544027993-37dbfe43562a?auto=format&fit=crop&q=80&w=800';
              }}
            />
            {/* Golden Halo Ring */}
            <div className="absolute -inset-4 border-2 border-dashed border-yellow-400/40 rounded-full animate-spin [animation-duration:30s]" />
          </div>

          {/* Countdown Clock */}
          <div className="absolute bottom-[-20px] bg-zinc-900 border border-zinc-700 p-3 rounded-2xl flex items-center gap-4 text-center shadow-xl">
            <div className="text-xs font-black text-yellow-400 tracking-widest uppercase [writing-mode:vertical-lr] scale-x-[-1] hidden md:block">
              התגלות
            </div>
            <div className="flex gap-2 text-sm font-bold">
              <div className="bg-black/50 px-3 py-2 rounded-lg border border-zinc-800">
                <span className="text-xl font-black text-yellow-400 block">{timeLeft.hours}</span>
                <span className="text-zinc-500 text-xs">שעות</span>
              </div>
              <div className="bg-black/50 px-3 py-2 rounded-lg border border-zinc-800">
                <span className="text-xl font-black text-yellow-400 block">{timeLeft.minutes}</span>
                <span className="text-zinc-500 text-xs">דקות</span>
              </div>
              <div className="bg-black/50 px-3 py-2 rounded-lg border border-zinc-800">
                <span className="text-xl font-black text-yellow-400 block">{timeLeft.seconds}</span>
                <span className="text-zinc-500 text-xs">שניות</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
