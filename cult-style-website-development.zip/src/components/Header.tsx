import { Shield, Sparkles, Flame, Eye } from 'lucide-react';

interface HeaderProps {
  setActiveTab: (tab: string) => void;
  activeTab: string;
}

export default function Header({ setActiveTab, activeTab }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 border-b border-yellow-500/30 bg-black/80 backdrop-blur-md">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between flex-wrap gap-4">
        <div 
          className="flex items-center gap-2 cursor-pointer group"
          onClick={() => setActiveTab('hero')}
        >
          <div className="relative">
            <Shield className="w-8 h-8 text-yellow-500 animate-pulse group-hover:rotate-180 transition-all duration-700" />
            <Eye className="w-4 h-4 text-red-500 absolute top-2 left-2 animate-ping" />
          </div>
          <span className="text-xl md:text-2xl font-black bg-gradient-to-r from-yellow-500 via-amber-200 to-yellow-600 bg-clip-text text-transparent drop-shadow-[0_0_15px_rgba(234,179,8,0.5)] tracking-widest">
            שוקיזם מוחלט
          </span>
        </div>

        <nav className="flex items-center flex-wrap gap-2 md:gap-4 text-sm font-bold text-gray-300">
          {[
            { id: 'hero', label: 'האור הגדול', icon: Sparkles },
            { id: 'quiz', label: 'מבחן קבלה', icon: Shield },
            { id: 'bless', label: 'מחולל ברכות', icon: Flame },
            { id: 'merch', label: 'חנות קודש', icon: Sparkles },
            { id: 'shrine', label: 'היכל ההתבודדות', icon: Eye },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border transition-all duration-300 ${
                  isActive
                    ? 'bg-yellow-500 text-black border-yellow-400 font-black shadow-[0_0_20px_rgba(234,179,8,0.4)]'
                    : 'bg-zinc-900/60 border-zinc-700/50 hover:border-yellow-500/50 hover:text-yellow-400'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div>
          <button 
            onClick={() => setActiveTab('quiz')}
            className="relative inline-flex items-center justify-center p-0.5 mb-2 me-2 overflow-hidden text-sm font-medium text-gray-900 rounded-lg group bg-gradient-to-br from-red-600 via-orange-500 to-yellow-400 group-hover:from-red-600 group-hover:to-yellow-400 hover:text-white dark:text-white focus:ring-4 focus:outline-none focus:ring-red-200 dark:focus:ring-red-800"
          >
            <span className="relative px-5 py-2.5 transition-all ease-in duration-75 bg-black rounded-md group-hover:bg-opacity-0 font-extrabold text-yellow-500 group-hover:text-black">
              תרום את נשמתך לרב
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}
