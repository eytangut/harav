import { Shield, Mail, Phone } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black border-t border-zinc-800 text-zinc-500 py-12">
      <div className="container mx-auto px-4 max-w-5xl text-center space-y-6">
        <div className="flex items-center justify-center gap-2 text-yellow-500/60">
          <Shield className="w-5 h-5 animate-pulse" />
          <span className="text-sm font-bold uppercase tracking-wider">
            שוקיזם מוחלט - 2026
          </span>
        </div>

        <p className="text-xs max-w-xl mx-auto leading-relaxed">
          * האתר הינו אתר סאטירי/הערצה הומוריסטי לחלוטין. מיועד להנאה אישית בלבד. כל קשר בין הכתוב לבין רב כזה או אחר במציאות הוא באחריות הקורא. אין לקחת את פסקי ההלכה או המוצרים ברצינות.
        </p>

        <div className="flex justify-center gap-6 text-sm font-medium">
          <a href="#" className="hover:text-yellow-500 flex items-center gap-1">
            <Mail className="w-4 h-4" /> צור קשר עם ההנהלה
          </a>
          <a href="#" className="hover:text-yellow-500 flex items-center gap-1">
            <Phone className="w-4 h-4" /> מוקד התמיכה של שוקי
          </a>
        </div>

        <div className="text-xs pt-4 border-t border-zinc-900 flex flex-col md:flex-row items-center justify-between gap-4">
          <div>נבנה באהבה מוחלטת עם ❤️ בהשראת האור</div>
          <div className="text-yellow-600 font-bold tracking-widest">אין עוד שוקי מלבדו!</div>
        </div>
      </div>
    </footer>
  );
}
