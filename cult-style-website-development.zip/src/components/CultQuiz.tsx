import { useState } from 'react';
import { Award, AlertCircle, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';

const questions = [
  {
    text: "כמה שעות ביום אתה מקדיש למחשבה עמוקה על פועלו של הרב שוקי?",
    options: [
      { text: "בין שעה לשעתיים (כופר מוחלט)", score: 0 },
      { text: "כל היום, חוץ מבזמן השינה", score: 10 },
      { text: "24/7! שוקי מופיע לי גם בחלומות בלילה (חסיד מן המניין)", score: 20 },
      { text: "אין לי זמן, הזמן עצמו הוא המצאה של שוקי", score: 25 },
    ],
  },
  {
    text: "מהו המשקה המקודש שמרווה את צמאונו הרוחני של הרב?",
    options: [
      { text: "מים מהברז בתוספת זיכוך נשמות", score: 15 },
      { text: "זירו קריר (כי שוקי שומר על גזרה קדושה)", score: 25 },
      { text: "דם הדרקונים הנורדיים האחרונים", score: 5 },
      { text: "קפה מבית פול", score: 10 },
    ],
  },
  {
    text: "אם הרב שוקי מביט בך ברחוב וקורץ, מה משמעות הדבר?",
    options: [
      { text: "חטאיי נמחלו מיד ל-10 הדורות הבאים שלי", score: 25 },
      { text: "יש לי משהו על האף", score: -10 },
      { text: "נבחרתי לשמש כנושא הכלים בטיש הבא", score: 15 },
      { text: "זה רק רפלקס של העין", score: 0 },
    ],
  },
  {
    text: "איך יש לנהוג בעת מפגש פיזי עם בגדי הקודש של הרב?",
    options: [
      { text: "לכבס אותם ביד עדינה", score: 5 },
      { text: "לנשק את המכפלת ולהתפלל לירידת גשמים", score: 25 },
      { text: "להגיד בנימוס שלום", score: 0 },
      { text: "לצלם סטורי בלי פילטר", score: 10 },
    ],
  },
];

export default function CultQuiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [userName, setUserName] = useState('');
  const [isCertified, setIsCertified] = useState(false);

  const handleAnswer = (points: number) => {
    const nextScore = score + points;
    setScore(nextScore);

    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < questions.length) {
      setCurrentQuestion(nextQuestion);
    } else {
      setShowResult(true);
      if (nextScore >= 70) {
        setIsCertified(true);
        confetti({
          particleCount: 150,
          spread: 80,
          origin: { y: 0.6 },
        });
      }
    }
  };

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowResult(false);
    setIsCertified(false);
  };

  return (
    <section className="py-16 bg-zinc-950 text-white min-h-[80vh] flex items-center">
      <div className="container mx-auto px-4 max-w-2xl">
        {!showResult ? (
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 md:p-10 shadow-[0_0_40px_rgba(234,179,8,0.1)] relative">
            {/* Progress Bar */}
            <div className="w-full bg-zinc-800 h-2 rounded-full mb-8">
              <div
                className="bg-gradient-to-r from-yellow-500 to-amber-400 h-2 rounded-full transition-all duration-500"
                style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
              />
            </div>

            <div className="text-yellow-500 text-sm font-black tracking-widest mb-2 uppercase">
              שאלה {currentQuestion + 1} מתוך {questions.length}
            </div>

            <h3 className="text-xl md:text-2xl font-bold text-zinc-100 mb-8">
              {questions[currentQuestion].text}
            </h3>

            <div className="space-y-4">
              {questions[currentQuestion].options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswer(option.score)}
                  className="w-full text-right p-4 rounded-xl bg-zinc-800/50 border border-zinc-700/50 hover:border-yellow-500 hover:bg-zinc-800 text-zinc-200 hover:text-yellow-400 font-medium transition-all duration-200 transform hover:-translate-y-0.5"
                >
                  {option.text}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-8 md:p-12 text-center shadow-[0_0_50px_rgba(234,179,8,0.2)]">
            {isCertified ? (
              <div className="space-y-6">
                <div className="inline-flex items-center justify-center w-20 h-20 bg-yellow-500/10 border-2 border-yellow-500 rounded-full text-yellow-400 mb-4 animate-pulse">
                  <Award className="w-10 h-10" />
                </div>
                <h3 className="text-3xl md:text-4xl font-extrabold text-yellow-400">
                  נמצאת ראוי/ה להצטרף לכת!
                </h3>
                <p className="text-zinc-300">
                  הציון שלך: <span className="font-bold text-yellow-500">{score} נקודות קודש.</span>
                </p>

                <div className="mt-8 p-6 bg-black border-2 border-dashed border-yellow-500 rounded-2xl relative">
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-zinc-900 px-4 text-xs font-bold text-yellow-500 border border-yellow-500 rounded-full">
                    תעודת נאמנות רשמית
                  </div>

                  <div className="py-4">
                    <input
                      type="text"
                      placeholder="הקלד את שמך לתעודה"
                      value={userName}
                      onChange={(e) => setUserName(e.target.value)}
                      className="w-full bg-zinc-850 bg-zinc-800 text-center text-xl font-bold py-2 px-4 rounded-lg border border-zinc-700 focus:border-yellow-500 text-white placeholder-zinc-500 mb-4 focus:outline-none"
                    />

                    {userName && (
                      <div className="border border-yellow-600/30 p-6 rounded-xl bg-yellow-600/5 mt-4">
                        <div className="text-yellow-400 font-serif text-2xl font-bold mb-1">
                          אישור חסידות עליון
                        </div>
                        <p className="text-zinc-300 text-sm mb-4">מוענק בזאת חסד מוחלט ל-</p>
                        <div className="text-3xl font-black text-white underline decoration-yellow-500 underline-offset-8 decoration-2">
                          {userName}
                        </div>
                        <p className="text-zinc-400 text-xs mt-6">
                          בחתימת ההנהלה הרוחנית העליונה של הכת.
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                <button
                  onClick={restartQuiz}
                  className="mt-6 flex items-center justify-center gap-2 mx-auto text-sm font-bold text-zinc-400 hover:text-yellow-500"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>להיבחן מחדש למען הגיבוש</span>
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-red-500/10 border border-red-500 rounded-full text-red-500 mb-4 animate-bounce">
                  <AlertCircle className="w-8 h-8" />
                </div>
                <h3 className="text-2xl md:text-3xl font-extrabold text-red-500">
                  לא מספיק שוקי בשבילך
                </h3>
                <p className="text-zinc-300">
                  השגת {score} נקודות בלבד. החזון שלך עדיין מטושטש על ידי כוחות חומריים וקליפות של בורות.
                </p>
                <div className="p-4 bg-zinc-850 bg-zinc-800/40 rounded-xl border border-zinc-800 text-sm text-zinc-400">
                  מומלץ לקרוא את ספר פניני שוקי ולחזור בעוד 10 דקות של טהרה.
                </div>

                <button
                  onClick={restartQuiz}
                  className="mt-6 flex items-center justify-center gap-2 bg-yellow-500 text-black font-black px-6 py-3 rounded-xl hover:bg-yellow-400 transition-all mx-auto"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>נסה שוב (מחילת עוונות מובטחת)</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
