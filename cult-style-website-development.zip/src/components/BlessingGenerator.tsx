import { useState } from 'react';
import { Sparkles, MessageSquare, ShieldCheck, Smile } from 'lucide-react';

const answers = [
  "שוקי רואה את הלב שלך. התשובה היא: סבלנות, ובינתיים קנה שווארמה בלאפה עם המון טחינה (אבל בלי עמבה).",
  "ברוך תהיה. הרב ממליץ לך להתרחק מאנשים שלא מחייכים בבוקר. המזל יאיר לך פנים בעוד 3 ימים.",
  "המצוקה שלך נשמעה. על פי תורת השוקיזם, עליך לומר 'שוקי מלך העולם' 18 פעמים מול המראה.",
  "אל חשש! הבעיה תיפתר ברגע שתפסיק לנסות לפתור אותה. פשוט תן לאנרגיית השוקי לזרום.",
  "פסק ההלכה הוא: מותר ומצווה לאכול שוקולד פרה עם סוכריות קופצות. זה מנקה את התדרים.",
  "הרב שוקי מוסר: 'מי שזורע דמעות – יקצור חיוכים'. במיוחד אם מדובר בחיוך של פרידמן.",
];

export default function BlessingGenerator() {
  const [name, setName] = useState('');
  const [question, setQuestion] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const generateBlessing = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !question) return;

    setLoading(true);
    setResult('');

    setTimeout(() => {
      const randomIndex = Math.floor(Math.random() * answers.length);
      setResult(answers[randomIndex]);
      setLoading(false);
    }, 1500);
  };

  return (
    <section className="py-16 bg-zinc-900 text-white border-y border-zinc-800">
      <div className="container mx-auto px-4 max-w-3xl">
        <div className="text-center mb-10">
          <div className="inline-flex p-3 rounded-full bg-yellow-500/10 border border-yellow-500/30 text-yellow-500 mb-4 animate-spin [animation-duration:10s]">
            <Sparkles className="w-8 h-8" />
          </div>
          <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-4">
            מחולל הברכות ופסקי ההלכה של שוקי
          </h2>
          <p className="text-zinc-400">
            הזן את שאלתך וקבל תשובה מיידית שמאירה את החשכה
          </p>
        </div>

        <div className="bg-black border border-zinc-800 rounded-3xl p-6 md:p-10 shadow-2xl">
          <form onSubmit={generateBlessing} className="space-y-6">
            <div>
              <label className="block text-zinc-300 font-bold mb-2 text-right">
                איך לקרוא לך, הו מאמין/ה יקר/ה?
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="ישראל ישראלי"
                className="w-full bg-zinc-900 text-right py-3 px-4 rounded-xl border border-zinc-700 focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500 text-white placeholder-zinc-600 focus:outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-zinc-300 font-bold mb-2 text-right">
                מה מעיק על נשמתך? (השאלה שלך לרב)
              </label>
              <textarea
                required
                rows={3}
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="למשל: האם כדאי לי לקנות דירה בפתח תקווה או לחכות?"
                className="w-full bg-zinc-900 text-right py-3 px-4 rounded-xl border border-zinc-700 focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500 text-white placeholder-zinc-600 focus:outline-none transition-all"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-yellow-500 via-amber-500 to-yellow-600 text-black font-black text-lg hover:brightness-110 disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_5px_20px_rgba(245,158,11,0.2)] transition-all duration-300"
            >
              {loading ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  <span>מתחבר לידע הקוסמי...</span>
                </div>
              ) : (
                <div className="flex items-center justify-center gap-2">
                  <MessageSquare className="w-5 h-5" />
                  <span>קבל ברכה ועצה לשעת משבר</span>
                </div>
              )}
            </button>
          </form>

          {result && (
            <div className="mt-8 p-6 bg-yellow-500/5 border border-yellow-500/40 rounded-2xl text-right animate-fade-in relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-4 opacity-5">
                <Smile className="w-32 h-32 text-yellow-500" />
              </div>

              <div className="flex items-center gap-2 text-yellow-500 font-extrabold text-lg mb-3">
                <ShieldCheck className="w-6 h-6" />
                <span>פסק הלכה וברכת קודש עבור {name}:</span>
              </div>
              <p className="text-xl font-bold text-zinc-200 leading-relaxed italic border-r-4 border-yellow-500 pr-4">
                "{result}"
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
