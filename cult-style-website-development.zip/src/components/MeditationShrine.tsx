import { useState, useEffect } from 'react';
import { Eye, ShieldAlert, Heart, Sun } from 'lucide-react';

export default function MeditationShrine() {
  const [meditating, setMeditating] = useState(false);
  const [spiritLevel, setSpiritLevel] = useState(0);
  const [phraseIndex, setPhraseIndex] = useState(0);

  const phrases = [
    "נשום פנימה את האוויר המטוהר של שוקי...",
    "נשוף החוצה את כל הרבנים האחרים שעברו לך בראש...",
    "תן לתדר הפרידמני לשטוף את הרגליים שלך...",
    "התחבר ליסוד האש שנמצא אצלך בכיס...",
    "הכול פתוח והרשות נתונה, במיוחד אם מדובר בחיוך של שוקי...",
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (meditating) {
      interval = setInterval(() => {
        setSpiritLevel((prev) => {
          if (prev >= 100) {
            setMeditating(false);
            return 100;
          }
          return prev + 1;
        });
      }, 300);
    }
    return () => clearInterval(interval);
  }, [meditating]);

  useEffect(() => {
    let phraseInterval: NodeJS.Timeout;
    if (meditating) {
      phraseInterval = setInterval(() => {
        setPhraseIndex((prev) => (prev + 1) % phrases.length);
      }, 4000);
    }
    return () => clearInterval(phraseInterval);
  }, [meditating]);

  const startMeditation = () => {
    setSpiritLevel(0);
    setMeditating(true);
  };

  return (
    <section className="py-16 bg-black text-white min-h-[85vh] flex items-center justify-center relative overflow-hidden">
      {meditating && (
        <div className="absolute inset-0 z-0 bg-yellow-500/5 animate-pulse" />
      )}

      <div className="container mx-auto px-4 max-w-2xl relative z-10 text-center">
        {!meditating ? (
          <div className="space-y-6">
            <div className="inline-flex p-4 rounded-full bg-yellow-500/10 border-2 border-yellow-500/30 text-yellow-500 animate-pulse">
              <Eye className="w-12 h-12" />
            </div>
            <h2 className="text-3xl md:text-5xl font-black text-white">
              היכל ההתבודדות וההארה
            </h2>
            <p className="text-zinc-400 max-w-md mx-auto leading-relaxed">
              שבו זקוף, שחררו את המחשבות והיכנסו לסנכרון מלא עם תדרי הזהב של הרב שוקי.
            </p>

            <button
              onClick={startMeditation}
              className="bg-gradient-to-r from-yellow-500 to-amber-500 text-black font-extrabold px-10 py-4 rounded-2xl text-xl hover:brightness-110 shadow-[0_10px_30px_rgba(234,179,8,0.3)] transition-all transform hover:-translate-y-1"
            >
              התחל מדיטציית שוקי עכשיו
            </button>
          </div>
        ) : (
          <div className="space-y-8 animate-fade-in">
            <div className="relative w-48 h-48 mx-auto">
              {/* Spinning Sacred Halo */}
              <div className="absolute -inset-4 border-4 border-dashed border-yellow-500 rounded-full animate-spin [animation-duration:15s]" />
              <img
                src="/shuki_saint.jpg"
                alt="שוקי בהארה"
                className="w-full h-full object-cover rounded-full filter saturate-150 contrast-125"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    'https://images.unsplash.com/photo-1544027993-37dbfe43562a?auto=format&fit=crop&q=80&w=800';
                }}
              />
            </div>

            <div className="h-16 flex items-center justify-center">
              <h3 className="text-2xl md:text-3xl font-bold text-yellow-400 animate-pulse text-center transition-all duration-1000">
                {phrases[phraseIndex]}
              </h3>
            </div>

            {/* Spirit Level Bar */}
            <div className="max-w-md mx-auto bg-zinc-900 border border-zinc-800 p-4 rounded-2xl">
              <div className="flex justify-between items-center mb-2 text-sm text-zinc-400">
                <span className="flex items-center gap-1 font-bold">
                  <Heart className="w-4 h-4 text-red-500 fill-red-500 animate-beat" />
                  איזון רוחני
                </span>
                <span className="font-black text-yellow-500">{spiritLevel}%</span>
              </div>
              <div className="w-full bg-zinc-800 h-4 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-yellow-500 via-amber-400 to-yellow-300 h-4 rounded-full transition-all duration-300"
                  style={{ width: `${spiritLevel}%` }}
                />
              </div>
            </div>

            <div className="text-xs text-zinc-500 flex items-center justify-center gap-1">
              <ShieldAlert className="w-4 h-4" />
              נא לא למצמץ עד לסיום החיבור
            </div>

            {spiritLevel === 100 && (
              <div className="mt-4 p-4 bg-yellow-500/20 border border-yellow-500/40 rounded-xl text-yellow-300 font-bold flex items-center justify-center gap-2 animate-bounce">
                <Sun className="w-5 h-5 fill-yellow-400 text-yellow-400 animate-spin" />
                <span>הנשמה שלך אוחדה בהצלחה עם שוקי!</span>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
