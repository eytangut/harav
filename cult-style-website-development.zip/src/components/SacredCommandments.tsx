import { Heart, Star, Sparkles, Check } from 'lucide-react';

const commandments = [
  "אל יהיו לך רבנים אחרים לפני שוקי. שוקי הוא התשובה לכל שאלה שאי פעם נשאלה.",
  "לא תעשה לך כל פסל ומסכה - פרט למסיכות של הרב שוקי (ניתן להשיג בחנות ב-499₪).",
  "זכור את יום חמישי לקדשו - יום הטיש הגדול של שוקי. חובה להדליק נר ריחני בצורת פטריית כמהין.",
  "כבד את הרב שוקי ואת כל מה שקשור אליו. הסטטוסים שלו בוואטסאפ הם דברי אלוהים חיים.",
  "לא תחלום על אנשים אחרים. המחשבה על שוקי מספיקה כדי למלא את כל מרחב הדמיון שלך.",
  "לא תגזול - אלא אם כן זה תרומה ישירה לקידום הפצת בשורת השוקיזם ברחבי היקום.",
  "לא תענה ברעך עד שקר - אלא אם כן מדובר בשבח והלל מופלגים על חוכמתו של שוקי.",
  "חובה לעמוד דום בכל פעם שמישהו אומר 'פרידמן' במרחק של עד 50 מטרים ממך.",
  "מותר להתווכח עם המדע. אם המדע אומר דבר אחד והרב שוקי אומר דבר אחר - הפיזיקה כנראה טועה.",
  "תמיד לשמור על חיוך שטוף זימה דתית בזמן שקוראים את דברי קודשו.",
];

export default function SacredCommandments() {
  return (
    <section className="py-16 bg-gradient-to-b from-zinc-950 to-black text-white">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center gap-2 text-yellow-500 mb-4 animate-bounce">
            <Sparkles className="w-6 h-6" />
            <Star className="w-8 h-8 fill-yellow-500" />
            <Sparkles className="w-6 h-6" />
          </div>
          <h2 className="text-3xl md:text-5xl font-extrabold bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-600 bg-clip-text text-transparent mb-4">
            עשרת דיברות השוקיזם המוחלט
          </h2>
          <p className="text-zinc-400 text-lg">
            החוקים שבלעדיהם הנשמה שלכם תסתובב בתוהו ובוהו לנצח
          </p>
        </div>

        <div className="space-y-4">
          {commandments.map((cmd, index) => (
            <div
              key={index}
              className="flex items-start gap-4 p-5 rounded-2xl bg-zinc-900/50 border border-zinc-800/80 hover:border-yellow-500/50 hover:bg-zinc-900 transition-all duration-300 transform hover:-translate-y-1"
            >
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-to-br from-yellow-500 to-amber-600 flex items-center justify-center font-black text-black text-lg shadow-[0_0_15px_rgba(234,179,8,0.4)]">
                {index + 1}
              </div>
              <div className="flex-1">
                <p className="text-lg text-zinc-200 leading-relaxed font-medium">
                  {cmd}
                </p>
              </div>
              <Check className="w-6 h-6 text-yellow-500 flex-shrink-0 self-center opacity-40 group-hover:opacity-100" />
            </div>
          ))}
        </div>

        <div className="mt-12 p-6 rounded-2xl bg-red-950/20 border border-red-900/50 text-center">
          <p className="text-red-400 text-sm flex items-center justify-center gap-2 font-bold">
            <Heart className="w-4 h-4 fill-red-500 text-red-500 animate-beat inline" />
            אי עמידה בדיברות עשויה לגרור שלילת הגישה לסטטוסים של שוקי לשבוע ימים!
          </p>
        </div>
      </div>
    </section>
  );
}
