import { useState } from 'react';
import { Eye, HeartHandshake, Smile, RefreshCcw } from 'lucide-react';

export default function ConfessionBooth() {
  const [confession, setConfession] = useState('');
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!confession.trim()) return;
    setIsSent(true);
    setConfession('');
  };

  return (
    <section className="py-16 bg-gradient-to-t from-black to-zinc-950 text-white">
      <div className="container mx-auto px-4 max-w-3xl">
        <div className="text-center mb-10">
          <div className="inline-flex p-3 bg-red-500/10 border border-red-500/40 rounded-full text-red-400 mb-4 animate-pulse">
            <Eye className="w-8 h-8" />
          </div>
          <h2 className="text-3xl md:text-5xl font-black text-white">
            תא הווידויים של היכל שוקי
          </h2>
          <p className="text-zinc-400 mt-2">
            ספרו לרב שוקי על רגעי החולשה שלכם. המחילה מובטחת לכל המאמין בכנות.
          </p>
        </div>

        {!isSent ? (
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 md:p-10 shadow-xl">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-zinc-300 font-bold mb-2 text-right">
                  הווידוי שלך (אל תתביישו, אנחנו רואים הכל גם ככה):
                </label>
                <textarea
                  required
                  rows={4}
                  value={confession}
                  onChange={(e) => setConfession(e.target.value)}
                  placeholder="למשל: שכחתי להגיד 'בוקר שוקי' היום בבוקר..."
                  className="w-full bg-zinc-800/60 text-right py-3 px-4 rounded-xl border border-zinc-700 focus:border-red-500 focus:ring-1 focus:ring-red-500 text-white placeholder-zinc-600 focus:outline-none transition-all"
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 text-white font-black text-lg hover:from-red-500 hover:to-amber-500 shadow-lg transition-all duration-300"
              >
                שדר את הווידוי לשמיים
              </button>
            </form>
          </div>
        ) : (
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-8 md:p-12 text-center shadow-2xl space-y-6 animate-fade-in">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-green-500/10 border-2 border-green-500 rounded-full text-green-400 mb-2">
              <HeartHandshake className="w-8 h-8 animate-bounce" />
            </div>
            <h3 className="text-2xl md:text-3xl font-extrabold text-green-400">
              הווידוי התקבל ונמחל!
            </h3>
            <p className="text-zinc-300">
              הוד קדושתו הרב שוקי פרידמן מסר שהוא מעריך את כנותך. הכתם על נשמתך הוסר באמצעות תוכנת הצפנה קוונטית.
            </p>

            <div className="flex items-center justify-center gap-2 text-yellow-500 font-bold text-sm">
              <Smile className="w-5 h-5" />
              <span>עכשיו לכו וחייכו אל היקום!</span>
            </div>

            <button
              onClick={() => setIsSent(false)}
              className="mt-4 inline-flex items-center gap-2 text-sm text-zinc-400 hover:text-white transition-colors"
            >
              <RefreshCcw className="w-4 h-4" />
              <span>יש לי עוד משהו להתוודות עליו</span>
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
