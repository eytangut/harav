import { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import CultQuiz from './components/CultQuiz';
import BlessingGenerator from './components/BlessingGenerator';
import MerchStore from './components/MerchStore';
import SacredCommandments from './components/SacredCommandments';
import MeditationShrine from './components/MeditationShrine';
import ConfessionBooth from './components/ConfessionBooth';
import Footer from './components/Footer';

export default function App() {
  const [activeTab, setActiveTab] = useState('hero');

  return (
    <div className="bg-black min-h-screen text-zinc-100 font-sans antialiased">
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="transition-all duration-300">
        {activeTab === 'hero' && (
          <>
            <Hero setActiveTab={setActiveTab} />
            <SacredCommandments />
            <ConfessionBooth />
          </>
        )}

        {activeTab === 'quiz' && <CultQuiz />}
        {activeTab === 'bless' && <BlessingGenerator />}
        {activeTab === 'merch' && <MerchStore />}
        {activeTab === 'shrine' && <MeditationShrine />}
      </main>

      <Footer />
    </div>
  );
}
