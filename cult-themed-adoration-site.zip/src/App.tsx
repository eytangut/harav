import { useEffect, useMemo, useRef, useState } from "react";

export default function App() {
  const [candles, setCandles] = useState(9843);
  const [amens, setAmens] = useState(45217);
  const [followers, setFollowers] = useState(12847);
  const [prayers, setPrayers] = useState([
    { name: "אליהו", text: "שוקי הושיעני! אני שלך לנצח", time: "לפני 2 דקות" },
    { name: "מרים", text: "אני סוגדת לרגלי קדושתך יום ולילה", time: "לפני 5 דקות" },
    { name: "דוד", text: "ויתרתי על הכל בשבילך רבי", time: "לפני 8 דקות" },
  ]);
  const [name, setName] = useState("");
  const [prayerText, setPrayerText] = useState("");
  const [blessing, setBlessing] = useState<string | null>(null);
  const [showOath, setShowOath] = useState(false);
  const [chanting, setChanting] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const teachings = useMemo(() => [
    "אין עוד מלבד שוקי. כל המחשבה אחרת - עבודה זרה.",
    "הסוגד לשוקי בכל לבבו - יזכה לחיי נצח בגן עדן השוקיזם.",
    "אל תטיל ספק. הספק הוא האויב. שוקי הוא האמת המוחלטת.",
    "ויתור על רכושך, משפחתך, חייך - למען שוקי, זו המצווה הגדולה.",
    "כל נשימה שלך שייכת לו. כל פעימה - הלל לשמו.",
    "הרב שוקי רואה הכל. יודע הכל. סולח רק למאמינים האמיתיים.",
    "התנתק מהעולם החיצון. רק בהיכל שוקי יש אמת.",
  ], []);

  const [teachingIndex, setTeachingIndex] = useState(0);

  useEffect(() => {
    const i = setInterval(() => setTeachingIndex(t => (t + 1) % teachings.length), 6000);
    return () => clearInterval(i);
  }, [teachings.length]);

  useEffect(() => {
    const i = setInterval(() => {
      setFollowers(f => f + Math.floor(Math.random() * 3));
      if (Math.random() > 0.7) setCandles(c => c + 1);
    }, 4000);
    return () => clearInterval(i);
  }, []);

  const commandments = [
    "לא יהיה לך רב אחר על פני שוקי",
    "תסגוד לשוקי בכל לבבך ובכל נפשך ובכל מאודך",
    "תזכור את יום הולדת שוקי לקדשו",
    "כבד את שוקי ואת משנתו כאילו הוא אביך",
    "לא תטיל ספק - הספק הוא מוות",
    "לא תדבר סרה בשוקי - לשונך תיכרת",
    "לא תגנוב מבט מזולתך אל שוקי",
    "תיתן מעשר וכל רכושך להיכל",
    "תפיץ את בשורת שוקי בכל העולם",
    "תמסור נפשך למען קדושת שוקי",
  ];

  const blessingsPool = [
    "בני היקר, אני רואה את נשמתך הטהורה. אתה נבחרת. המשך לסגוד ואזכה אותך בניסים.",
    "שוקי מברך אותך באור אינסופי. מעתה, כל צעדיך מודרכים על ידי.",
    "האמונה שלך טהורה. אני מקבל אותך לעדה הקדושה. אין דרך חזרה - וגם לא תרצה.",
    "ברוך אתה לשוקי. נתתי לך חלק מחכמתי האינסופית. אל תבזבז אותה.",
    "נשמתך נקשרה לנשמתי לנצח נצחים. אתה שלי. אני שלך.",
  ];

  const handlePrayer = () => {
    if (!name || !prayerText) return;
    setPrayers(p => [{ name, text: prayerText, time: "עכשיו" }, ...p.slice(0, 5)]);
    setBlessing(blessingsPool[Math.floor(Math.random() * blessingsPool.length)]);
    setName("");
    setPrayerText("");
    setAmens(a => a + 1);
  };

  const lightCandle = () => {
    setCandles(c => c + 1);
    // spark effect
    const el = document.createElement("div");
    el.className = "fixed text-4xl pointer-events-none z-50";
    el.style.left = Math.random() * window.innerWidth + "px";
    el.style.top = Math.random() * window.innerHeight * 0.5 + 200 + "px";
    el.textContent = "🕯️";
    el.style.animation = "float 3s ease-out forwards";
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  };

  const toggleChant = () => {
    if (!audioRef.current) return;
    if (chanting) {
      audioRef.current.pause();
    } else {
      audioRef.current.volume = 0.3;
      audioRef.current.play().catch(() => {});
    }
    setChanting(!chanting);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-[#030303] text-zinc-100 relative overflow-hidden selection:bg-amber-500/30 selection:text-amber-200">
      {/* Background */}
      <div className="fixed inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(120,53,15,0.3),transparent_60%),radial-gradient(ellipse_at_bottom,_rgba(69,26,3,0.4),transparent_70%)]" />
        <img src="/images/temple.jpg" alt="" className="absolute inset-0 w-full h-full object-cover opacity-[0.15] mix-blend-overlay" />
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23fbbf24' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      {/* Smoke */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        {[...Array(6)].map((_, i) => (
          <div
            key={i}
            className="absolute bottom-0 w-40 h-40 rounded-full blur-3xl"
            style={{
              left: `${10 + i * 16}%`,
              background: "radial-gradient(circle, rgba(251,191,36,0.15), transparent 70%)",
              animation: `smoke ${15 + i * 3}s linear infinite`,
              animationDelay: `${i * 2}s`,
            }}
          />
        ))}
      </div>

      <audio ref={audioRef} loop src="https://cdn.pixabay.com/audio/2022/03/24/audio_e5bb0f6be4.mp3" />

      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur-xl border-b border-amber-900/30 bg-black/70">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="absolute -inset-2 bg-amber-500/20 rounded-full blur-xl animate-pulse" />
              <div className="relative w-10 h-10 rounded-full bg-gradient-to-b from-amber-400 to-amber-700 flex items-center justify-center shadow-[0_0_30px_rgba(245,158,11,0.5)]">
                <span className="hebrew-serif text-xl font-black text-black">ש</span>
              </div>
            </div>
            <div>
              <div className="hebrew-serif text-[11px] tracking-[0.2em] text-amber-400/80">היכל הקודש</div>
              <div className="text-sm font-bold tracking-wide">הרב שוקי פרידמן שליט"א</div>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-6 text-[13px]">
            <a href="#torah" className="hover:text-amber-300 transition">תורתו</a>
            <a href="#commandments" className="hover:text-amber-300 transition">הדיברות</a>
            <a href="#prayers" className="hover:text-amber-300 transition">תפילות</a>
            <button onClick={toggleChant} className={`px-3 py-1.5 rounded-full border transition ${chanting ? "bg-amber-500/20 border-amber-500 text-amber-200" : "border-zinc-700 hover:border-amber-800"}`}>
              {chanting ? "■ הפסק מזמור" : "♪ מזמור קדוש"}
            </button>
          </div>
        </div>
      </header>

      <main className="relative z-10">
        {/* HERO */}
        <section className="relative min-h-[92vh] flex items-center">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 py-12 grid lg:grid-cols-[1.1fr_0.9fr] gap-12 items-center w-full">
            <div className="order-2 lg:order-1">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-200/90 text-xs mb-6">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                שידור חי מההיכל • {followers.toLocaleString('he-IL')} נשמות מחוברות
              </div>

              <h1 className="hebrew-serif text-5xl sm:text-7xl lg:text-8xl font-black leading-[0.9] tracking-tight">
                <span className="block text-zinc-500 text-2xl font-light mb-2">האור. האמת. הדרך.</span>
                <span className="bg-gradient-to-b from-amber-200 via-amber-400 to-amber-700 bg-clip-text text-transparent drop-shadow-[0_0_40px_rgba(245,158,11,0.3)]">
                  שוקי
                </span>
                <span className="block text-zinc-100 mt-1">הוא הכל</span>
              </h1>

              <p className="mt-6 text-lg sm:text-xl text-zinc-300 max-w-xl leading-relaxed">
                אין עוד מלבדו. <span className="text-amber-300 font-medium">הרב שוקי פרידמן שליט"א</span> — המשיח של דורנו, 
                האמת המוחלטת, האור שיגאל את נשמותינו האבודות. סגדו. האמינו. היכנעו.
              </p>

              <div className="mt-8 flex flex-wrap gap-3">
                <button onClick={() => setShowOath(true)} className="group relative px-8 py-4 bg-gradient-to-b from-amber-400 to-amber-600 text-black font-bold rounded-xl shadow-[0_0_40px_rgba(245,158,11,0.4)] hover:shadow-[0_0_60px_rgba(245,158,11,0.6)] transition-all overflow-hidden">
                  <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 translate-x-[-200%] group-hover:translate-x-[200%] transition-transform duration-1000" />
                  <span className="relative flex items-center gap-2">
                    נשבע אמונים לנצח
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
                  </span>
                </button>
                <button onClick={lightCandle} className="px-6 py-4 rounded-xl border border-amber-900/50 bg-black/50 backdrop-blur hover:bg-amber-950/30 transition flex items-center gap-2">
                  <span className="text-xl animate-flicker">🕯️</span> הדלק נר קודש
                </button>
              </div>

              <div className="mt-10 grid grid-cols-3 gap-6 max-w-lg">
                {[
                  { label: "נשמות שנושעו", value: followers },
                  { label: "נרות דולקים", value: candles },
                  { label: 'ענו "אמן"', value: amens },
                ].map((s) => (
                  <div key={s.label} className="text-center">
                    <div className="hebrew-serif text-3xl font-bold text-amber-300">{s.value.toLocaleString('he-IL')}</div>
                    <div className="text-[11px] text-zinc-500 mt-1 tracking-wide">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="order-1 lg:order-2 relative">
              <div className="relative mx-auto w-[340px] sm:w-[420px] aspect-[4/5]">
                {/* Glow */}
                <div className="absolute -inset-10 bg-amber-500/20 rounded-full blur-[80px] animate-pulse" />
                <div className="absolute -inset-6 bg-gradient-to-b from-amber-400/30 to-transparent rounded-[2rem] blur-2xl" />
                
                {/* Frame */}
                <div className="relative h-full rounded-[2rem] overflow-hidden border border-amber-900/50 bg-black shadow-2xl">
                  <img src="/images/rabbi-shuki.jpg" alt="הרב שוקי" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
                  <div className="absolute inset-0 mix-blend-overlay opacity-40" style={{ backgroundImage: "url('https://grainy-gradients.vercel.app/noise.svg')" }} />
                  
                  {/* Halo */}
                  <div className="absolute top-[12%] left-1/2 -translate-x-1/2 w-[70%] aspect-square">
                    <div className="w-full h-full rounded-full border-2 border-amber-400/30 animate-glow" />
                    <div className="absolute inset-3 rounded-full border border-amber-300/20" />
                  </div>

                  <div className="absolute bottom-0 inset-x-0 p-6">
                    <div className="hebrew-serif text-2xl font-bold text-amber-100 drop-shadow-[0_2px_10px_black]">רבינו הקדוש</div>
                    <div className="text-amber-200/80 text-sm">שוקי פרידמן שליט"א • אור העולם</div>
                  </div>
                </div>

                {/* Floating mantras */}
                <div className="absolute -right-8 top-10 hidden sm:block">
                  <div className="px-3 py-1.5 rounded-lg bg-black/80 border border-amber-900/50 backdrop-blur text-xs text-amber-200/80 animate-float">קדוש קדוש קדוש</div>
                </div>
                <div className="absolute -left-10 bottom-20 hidden sm:block">
                  <div className="px-3 py-1.5 rounded-lg bg-black/80 border border-amber-900/50 backdrop-blur text-xs text-amber-200/80 animate-float" style={{ animationDelay: "1s" }}>אין עוד מלבדו</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Teaching ticker */}
        <section id="torah" className="border-y border-amber-950/50 bg-black/60 backdrop-blur-xl">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 py-4 flex items-center gap-4">
            <div className="shrink-0 w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center">
              <span className="text-amber-400">✦</span>
            </div>
            <div className="overflow-hidden flex-1">
              <div key={teachingIndex} className="animate-[fadeIn_0.8s_ease] hebrew-serif text-lg sm:text-xl text-amber-100">
                "{teachings[teachingIndex]}"
              </div>
            </div>
            <div className="text-[10px] tracking-widest text-zinc-600 hidden sm:block">דברי קודש • מתחלף</div>
          </div>
        </section>

        {/* Commandments */}
        <section id="commandments" className="py-20 sm:py-28">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <div className="max-w-3xl mx-auto text-center mb-14">
              <div className="hebrew-serif text-amber-400 text-sm tracking-[0.3em] mb-3">עֲשֶׂרֶת הַדִּבְּרוֹת</div>
              <h2 className="hebrew-serif text-4xl sm:text-5xl font-black">דיברות השוקיזם הקדוש</h2>
              <p className="mt-4 text-zinc-400">נמסרו בהר סיני החדש, מפי רבינו שוקי בכבודו ובעצמו. מי שיעבור עליהן - נפשו תאבד.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-4 max-w-5xl mx-auto">
              {commandments.map((cmd, i) => (
                <div key={i} className="group relative">
                  <div className="absolute -inset-px bg-gradient-to-b from-amber-800/50 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 blur transition" />
                  <div className="relative flex gap-4 p-5 rounded-2xl bg-zinc-950/70 border border-zinc-900 hover:border-amber-900/50 backdrop-blur transition">
                    <div className="shrink-0 w-10 h-10 rounded-xl bg-gradient-to-b from-amber-500/20 to-amber-700/20 border border-amber-900/50 flex items-center justify-center hebrew-serif font-bold text-amber-300">
                      {i + 1}
                    </div>
                    <div className="pt-1.5 text-[15px] leading-relaxed text-zinc-200">{cmd}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-12 text-center">
              <button onClick={() => setAmens(a => a + 1)} className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-zinc-900 border border-zinc-800 hover:border-amber-800 hover:bg-amber-950/30 transition">
                <span className="text-amber-400">אמן אמן אמן</span>
                <span className="text-xs text-zinc-500">({amens.toLocaleString('he-IL')})</span>
              </button>
            </div>
          </div>
        </section>

        {/* Prayer Wall */}
        <section id="prayers" className="py-20 border-y border-zinc-900 bg-[radial-gradient(ellipse_at_center,_rgba(120,53,15,0.15),transparent_70%)]">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 grid lg:grid-cols-[1.1fr_0.9fr] gap-12 items-start">
            <div>
              <h3 className="hebrew-serif text-3xl sm:text-4xl font-bold mb-3">קיר התפילות הקדוש</h3>
              <p className="text-zinc-400 mb-6">כתוב את תחינתך. הרב שוקי קורא כל מילה. הסוגדים האמיתיים נענים תוך 3 ימים.</p>
              
              <div className="space-y-3">
                <input value={name} onChange={e => setName(e.target.value)} placeholder="שמך הטהור" className="w-full px-4 py-3 bg-black/60 border border-zinc-800 rounded-xl focus:outline-none focus:border-amber-700/50 text-[15px]" />
                <textarea value={prayerText} onChange={e => setPrayerText(e.target.value)} placeholder="רבינו שוקי... אני סוגד לך... קח את נשמתי..." rows={4} className="w-full px-4 py-3 bg-black/60 border border-zinc-800 rounded-xl focus:outline-none focus:border-amber-700/50 text-[15px] resize-none" />
                <button onClick={handlePrayer} disabled={!name || !prayerText} className="w-full py-3 rounded-xl bg-gradient-to-b from-amber-500 to-amber-700 text-black font-bold disabled:opacity-40 disabled:cursor-not-allowed hover:shadow-[0_0_30px_rgba(245,158,11,0.3)] transition">
                  שלח תפילה להיכל
                </button>
              </div>

              {blessing && (
                <div className="mt-6 p-5 rounded-2xl bg-amber-950/30 border border-amber-900/50 backdrop-blur">
                  <div className="text-[11px] tracking-widest text-amber-400/80 mb-2">ברכה אישית מרבינו</div>
                  <div className="hebrew-serif text-amber-100 leading-relaxed">"{blessing}"</div>
                  <div className="mt-3 text-right text-xs text-amber-300/60">— שוקי פרידמן שליט"א</div>
                </div>
              )}
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between mb-2">
                <div className="text-sm text-zinc-500">תפילות אחרונות • מתקבלות עכשיו</div>
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              </div>
              {prayers.map((p, i) => (
                <div key={i} className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-900 backdrop-blur">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-medium text-amber-200/90">{p.name} <span className="text-zinc-600">•</span> <span className="text-[12px] text-zinc-500">{p.time}</span></div>
                      <div className="mt-1 text-[14px] text-zinc-300 leading-snug">{p.text}</div>
                    </div>
                    <button onClick={() => setAmens(a => a + 1)} className="shrink-0 text-[11px] px-2.5 py-1 rounded-full bg-zinc-900 border border-zinc-800 hover:border-amber-800 text-zinc-400 hover:text-amber-300 transition">אמן</button>
                  </div>
                </div>
              ))}
              <div className="pt-2 text-center">
                <div className="inline-flex items-center gap-2 text-[12px] text-zinc-600">
                  <span>•</span> כל המתפלל כאן - נשמתו נרשמת בספר החיים של שוקי <span>•</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials cult */}
        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <div className="text-center mb-12">
              <h3 className="hebrew-serif text-3xl sm:text-4xl font-bold">עדויות מאמינים</h3>
              <p className="text-zinc-500 mt-2">הם ויתרו על הכל. קיבלו הכל.</p>
            </div>
            <div className="grid md:grid-cols-3 gap-5">
              {[
                { n: "יוסף ב.", t: "מאז שאני סוגד לשוקי 7 פעמים ביום, הסרטן נעלם. הרופאים בהלם. אני לא. שוקי הוא הרופא.", d: "חבר עדה 3 שנים" },
                { n: "רחל ל.", t: "עזבתי בעל, ילדים, עבודה. עברתי לגור בהיכל. זו ההחלטה הכי טובה בחיי. שוקי הוא בעלי האמיתי.", d: "משרתת קודש" },
                { n: "אברהם ק.", t: "תרמתי את כל חסכונותי - 847,000₪. למחרת זכיתי בלוטו. צירוף מקרים? לא אצל שוקי.", d: "תורם זהב" },
              ].map((x) => (
                <div key={x.n} className="relative p-[1px] rounded-2xl bg-gradient-to-b from-amber-900/50 to-transparent">
                  <div className="h-full p-6 rounded-2xl bg-zinc-950">
                    <div className="text-amber-400 mb-3">★★★★★</div>
                    <p className="text-[15px] leading-relaxed text-zinc-200 hebrew-serif">"{x.t}"</p>
                    <div className="mt-4 pt-4 border-t border-zinc-900 flex items-center justify-between">
                      <div className="text-sm font-medium">{x.n}</div>
                      <div className="text-[11px] text-zinc-600">{x.d}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="py-24 relative">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(245,158,11,0.15),transparent_60%)]" />
          <div className="relative mx-auto max-w-4xl px-4 sm:px-6 text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/50 border border-red-900/50 text-red-300/80 text-xs mb-6">
              אזהרת קודש
            </div>
            <h4 className="hebrew-serif text-4xl sm:text-5xl font-black leading-tight">
              מי שלא יסגוד <span className="text-amber-400">לשוקי</span> עכשיו —
              <br />נשמתו תאבד לנצח
            </h4>
            <p className="mt-5 text-zinc-400 max-w-2xl mx-auto">אין זמן לספק. אין מקום לכופרים. הדלת נסגרת בחצות. היכנס עכשיו או תישאר בחושך לנצח נצחים.</p>
            <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
              <button onClick={() => setShowOath(true)} className="px-8 py-4 rounded-xl bg-white text-black font-bold hover:bg-zinc-200 transition shadow-xl">אני נכנע. קח אותי שוקי.</button>
              <button onClick={lightCandle} className="px-8 py-4 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-amber-800 transition">הדלק נר אחרון ({candles.toLocaleString('he-IL')})</button>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-zinc-900 py-10 text-center text-[12px] text-zinc-600">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="hebrew-serif text-zinc-500 mb-2">היכל הרב שוקי פרידמן שליט"א • כל הזכויות שמורות לאור האינסופי</div>
          <div>אין עוד מלבדו • קדוש קדוש קדוש שוקי צבאות • ברוך שמו לעולם ועד</div>
        </div>
      </footer>

      {/* Oath Modal */}
      {showOath && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" onClick={() => setShowOath(false)} />
          <div className="relative w-full max-w-lg">
            <div className="absolute -inset-1 bg-gradient-to-b from-amber-600 to-amber-900 rounded-[2rem] blur-2xl opacity-50" />
            <div className="relative rounded-[1.5rem] border border-amber-900/50 bg-zinc-950 p-8 shadow-2xl">
              <div className="text-center">
                <div className="mx-auto w-16 h-16 rounded-full bg-gradient-to-b from-amber-400 to-amber-700 flex items-center justify-center shadow-[0_0_40px_rgba(245,158,11,0.5)] mb-4">
                  <span className="hebrew-serif text-3xl font-black text-black">ש</span>
                </div>
                <h5 className="hebrew-serif text-2xl font-bold text-amber-100">שבועת אמונים נצחית</h5>
                <p className="mt-2 text-sm text-zinc-400">קרא בקול. זה מחייב את נשמתך.</p>
              </div>

              <div className="mt-6 p-4 rounded-xl bg-black/60 border border-amber-950/50 text-[14px] leading-relaxed text-amber-100/90 hebrew-serif">
                אני נשבע/ת באלוהי שוקי, למסור נפשי, רוחי, נשמתי, כספי וגופי לרבינו הקדוש שוקי פרידמן שליט"א.
                לא יהיה לי רב אחר. לא אטיל ספק לעולם. אסגוד לו יום ולילה. אמות למענו אם יידרש.
                זוהי שבועתי. זוהי אמונתי. זוהי דרכי היחידה.
              </div>

              <div className="mt-6 grid grid-cols-2 gap-3">
                <button onClick={() => { setShowOath(false); setFollowers(f => f + 1); setAmens(a => a + 3); }} className="py-3 rounded-xl bg-gradient-to-b from-amber-500 to-amber-700 text-black font-bold hover:shadow-[0_0_30px_rgba(245,158,11,0.4)] transition">
                  נשבע/ת! קח אותי
                </button>
                <button onClick={() => setShowOath(false)} className="py-3 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition">עוד לא מוכן</button>
              </div>
              <div className="mt-3 text-center text-[11px] text-zinc-600">* השבועה נרשמת בספר החיים הנצחי</div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(6px) } to { opacity: 1; transform: translateY(0) } }
      `}</style>
    </div>
  );
}